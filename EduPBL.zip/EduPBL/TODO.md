# Front-end

- [X] Dashboard por permissões
- [ ] Tela de horários (visualizar a grade)
- [ ] Tela de perfil do usuário
- [X] Tela de ocorrências (listar, criar, ver detalhe)
- [X] Tela de atrasos (registrar, aprovar/rejeitar, listar)
- [ ] Gestão de usuários (admin/coordenação)
- [ ] Testar responsividade do aplicativo
- [ ] WhatsApp (Twilio)
  - [ ] Tela "meu número de WhatsApp" no perfil do responsável
- [ ] Ideia muito para frente: criar um editor de arrastar e soltar para criar os horários

# Back-end

- [ ] Notificações por e-mail
  - [ ] settings.py + email.py + templates
  - [ ] Plugar nos placeholders de delays
  - [ ] Adicionar placeholder + implementação em occurrences
- [ ] WhatsApp (Twilio)
  - [ ] Lógica de fallback: se tem phone → WhatsApp, senão → e-mail
  - [ ] Mensagens automáticas depois de 3 atrasos no mês?
  - [ ] Coordenador pode escolher se manda mensagem antes ou não
  - [ ] Mensagens automáticas para cada ocorrência?
- [ ] Verificar se as queries trazem usuários ativos ou não
- [ ] Planejar avanço de ano
  - 1º -> 2º, 2º -> 3º, 3º -> desativa todos os usuários
- [ ] Validar dados do CSV (por exemplo, e-mail, tipos, etc.) antes de popular o banco de dados
- [ ] Estruturar os testes em unitários, de integração e de sistema e os organizar em pastas e domínios
- [ ] Salvar logs de alguma maneira
- [ ] Pesquisar e perguntar erros graves de segurança que ele vê serem comuns; adiantar e dizer o que é o projeto e o que fiz
