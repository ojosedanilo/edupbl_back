#!/usr/bin/env python3
"""
Dev Runner — inicia serviços do EduPBL com controle avançado.
"""

import argparse
import os
import platform
import subprocess
import sys
import threading
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent

# =============================
# ⚙️ CONFIG
# =============================

# 🔌 O que iniciar
START_DOCKER = True
START_BACKEND = True
START_FRONTEND = True

# 📺 Logs
SHOW_DOCKER_LOGS = False
SHOW_BACKEND_LOGS = False
SHOW_FRONTEND_LOGS = False

# 💣 Criticidade (se morrer → derruba tudo)
BACKEND_IS_CRITICAL = False
FRONTEND_IS_CRITICAL = False
DOCKER_IS_CRITICAL = True  # (não monitorado diretamente)

# 🔄 Restart automático
RESTART_BACKEND = False
RESTART_FRONTEND = False


# =============================
# 🎨 CORES
# =============================
class Colors:
    RESET = "\033[0m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    CYAN = "\033[36m"


# =============================
# 🧠 UTIL
# =============================
def get_venv_python(venv_path):
    if platform.system() == "Windows":
        return os.path.join(venv_path, "Scripts", "python.exe")
    return os.path.join(venv_path, "bin", "python")


def stream_output(pipe, prefix, color):
    for line in iter(pipe.readline, b""):
        sys.stdout.write(
            f"{color}[{prefix}]{Colors.RESET} {line.decode(errors='ignore')}"
        )
    pipe.close()


def start_process(cmd, cwd, name, color, show_output=True, shell=False):
    if show_output:
        proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            shell=shell,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            bufsize=1,
        )

        thread = threading.Thread(
            target=stream_output,
            args=(proc.stdout, name, color),
            daemon=True,
        )
        thread.start()
    else:
        proc = subprocess.Popen(
            cmd,
            cwd=cwd,
            shell=shell,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    return proc


def start_docker_desktop():
    try:
        print(f"{Colors.CYAN}🐳 Iniciando Docker Desktop...{Colors.RESET}")
        subprocess.run(
            ["docker", "desktop", "start"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception as e:
        print(f"{Colors.YELLOW}⚠️ Erro ao iniciar Docker: {e}{Colors.RESET}")


def wait_for_docker(timeout=60):
    print(f"{Colors.CYAN}⏳ Aguardando Docker...{Colors.RESET}")
    start = time.time()

    while time.time() - start < timeout:
        try:
            result = subprocess.run(
                ["docker", "info"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:
                print(f"{Colors.GREEN}✅ Docker pronto!{Colors.RESET}")
                return True
        except Exception:
            pass

        time.sleep(2)

    print(f"{Colors.RED}❌ Timeout Docker{Colors.RESET}")
    return False


# =============================
# 🚀 MAIN
# =============================
def run_servers(venv_path, args):
    backend_dir = ROOT / "backend"
    frontend_dir = ROOT / "frontend"

    python_exe = get_venv_python(venv_path)
    use_shell = platform.system() == "Windows"

    processes = []

    try:
        # =============================
        # 🐳 DOCKER
        # =============================
        if args.start_docker:
            start_docker_desktop()

            if not wait_for_docker():
                return

            subprocess.run(
                ["docker", "start", args.container],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

        # =============================
        # 🚀 BACKEND
        # =============================
        if args.start_backend:
            if not os.path.exists(python_exe):
                print(f"{Colors.RED}❌ Python não encontrado{Colors.RESET}")
                return

            print(f"{Colors.GREEN}🚀 Backend...{Colors.RESET}")

            cmd = [
                python_exe,
                "-m",
                "uvicorn",
                "app.main:app",
                "--reload",
                "--host",
                "0.0.0.0",
                "--port",
                "8000",
            ]

            proc = start_process(
                cmd,
                cwd=backend_dir,
                name="backend",
                color=Colors.GREEN,
                show_output=args.show_backend,
            )

            processes.append(
                (
                    "backend",
                    proc,
                    {
                        "cmd": cmd,
                        "cwd": backend_dir,
                        "color": Colors.GREEN,
                        "show_output": args.show_backend,
                        "shell": False,
                        "critical": BACKEND_IS_CRITICAL,
                        "restart": RESTART_BACKEND,
                    },
                )
            )

        # =============================
        # ⚡ FRONTEND
        # =============================
        if args.start_frontend:
            print(f"{Colors.BLUE}⚡ Frontend...{Colors.RESET}")

            cmd = ["pnpm", "run", "dev", "--", "--host"]

            proc = start_process(
                cmd,
                cwd=frontend_dir,
                name="frontend",
                color=Colors.BLUE,
                show_output=args.show_frontend,
                shell=use_shell,
            )

            processes.append(
                (
                    "frontend",
                    proc,
                    {
                        "cmd": cmd,
                        "cwd": frontend_dir,
                        "color": Colors.BLUE,
                        "show_output": args.show_frontend,
                        "shell": use_shell,
                        "critical": FRONTEND_IS_CRITICAL,
                        "restart": RESTART_FRONTEND,
                    },
                )
            )

        print(f"\n{Colors.GREEN}✅ Rodando! Ctrl+C para parar\n{Colors.RESET}")

        # =============================
        # 🔁 MONITORAMENTO INTELIGENTE
        # =============================
        while True:
            time.sleep(1)

            for i, (name, proc, meta) in enumerate(processes):
                if proc.poll() is not None:
                    print(f"{Colors.YELLOW}⚠️ {name} morreu{Colors.RESET}")

                    # 🔄 restart
                    if meta["restart"]:
                        print(f"{Colors.CYAN}🔄 Reiniciando {name}{Colors.RESET}")

                        new_proc = start_process(
                            meta["cmd"],
                            cwd=meta["cwd"],
                            name=name,
                            color=meta["color"],
                            show_output=meta["show_output"],
                            shell=meta["shell"],
                        )

                        processes[i] = (name, new_proc, meta)
                        continue

                    # 💣 crítico
                    if meta["critical"]:
                        print(
                            f"{Colors.RED}💥 {name} é crítico. Encerrando...{Colors.RESET}"
                        )
                        return

                    # 🟡 não crítico
                    print(f"{Colors.YELLOW}⚠️ Ignorando {name}{Colors.RESET}")
                    processes.pop(i)
                    break

    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}🛑 Encerrando...{Colors.RESET}")

    finally:
        for _, proc, _ in processes:
            proc.terminate()

        if args.start_docker:
            subprocess.run(["docker", "stop", args.container])

        print(f"{Colors.GREEN}✅ Finalizado{Colors.RESET}")


# =============================
# 🧠 CLI
# =============================
def parse_args():
    parser = argparse.ArgumentParser()

    parser.add_argument("--container", default="edupbl_db")

    # serviços
    parser.add_argument(
        "--no-docker", action="store_false", dest="start_docker", default=START_DOCKER
    )
    parser.add_argument(
        "--no-backend",
        action="store_false",
        dest="start_backend",
        default=START_BACKEND,
    )
    parser.add_argument(
        "--no-frontend",
        action="store_false",
        dest="start_frontend",
        default=START_FRONTEND,
    )

    # logs
    parser.add_argument("--show-docker", action="store_true", default=SHOW_DOCKER_LOGS)
    parser.add_argument(
        "--hide-backend",
        action="store_false",
        dest="show_backend",
        default=SHOW_BACKEND_LOGS,
    )
    parser.add_argument(
        "--hide-frontend",
        action="store_false",
        dest="show_frontend",
        default=SHOW_FRONTEND_LOGS,
    )

    return parser.parse_args()


# =============================
# ▶️ ENTRYPOINT
# =============================
if __name__ == "__main__":
    args = parse_args()
    venv_path = ROOT / "backend" / ".venv"

    run_servers(str(venv_path), args)
