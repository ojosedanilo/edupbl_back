# EduPBL

## 🖥️ Tecnologias do Front-End

- **Node.js** → runtime JS
- **pnpm** → gerenciador de pacotes
- **Vite** → bundler/dev server
- **React + TypeScript** → UI
- **SWC** → compilador
- **TanStack Query** → estado servidor
- **React Router** → rotas
- **TailwindCSS** → estilos utilitários
- **Material UI (MUI)** → biblioteca de componentes UI

## 🧠 Tecnologias do Back-End

- **Python** → linguagem ensinada no curso + rápida prototipação
- **uv** → gerenciador de pacotes e ambientes virtuais
- **FastAPI** → API
- **Pydantic** → schemas/contratos
- **SQLAlchemy 2.0** → ORM de banco de dados
- **PostgreSQL** → banco de dados

## 🧩 Camadas

|           Coluna 1           |
| :--------------------------: |
| React + TS + Tailwind + MUI |
|              ↓              |
| TanStack Query (HTTP State) |
|              ↓              |
| FastAPI (Rules / Validation) |
|              ↓              |
|   SQLAlchemy (Persistence)   |
|              ↓              |
|          PostgreSQL          |

## 📁 Estrutura geral do repositório

```
EduPBL/
├── frontend/   → React App
├── backend/    → FastAPI
└── docs/       → diagramas e decisões
```

---

# 📦 Instalação

## 📋 Pré-requisitos globais

- [Docker](https://docs.docker.com/get-docker/)
- [uv](https://docs.astral.sh/uv/getting-started/installation/) (gerenciador de pacotes Python)
- [Node.js](https://nodejs.org/) (versão LTS)
- [pnpm](https://pnpm.io/installation)

---

## 🚀 Setup do Front-End

```bash
cd frontend
pnpm install   # instala as dependências
pnpm run dev   # inicia o servidor de desenvolvimento
```

---

## 🚀 Setup do Back-End

### 1. Copiar variáveis de ambiente

```bash
cd backend
cp .env.example .env
```

### 2. Subir o banco de dados via Docker

```bash
docker compose up -d
```

> O container já cria o banco automaticamente. Não é necessário nenhum script de inicialização manual.

### 3. Criar ambiente virtual e instalar dependências

```bash
uv sync
```

### 4. Ativar o ambiente virtual

```bash
# Linux/macOS
source .venv/bin/activate

# Windows (PowerShell)
.venv\Scripts\Activate.ps1
```

### 5. Rodar as migrations

```bash
alembic upgrade head
```

### 6. Popular o banco com dados de teste

```bash
python scripts/seed_db.py
```

### 7. Iniciar o servidor

```bash
task run
```

---

## ⚠️ Solução de problemas

### Erro: `type "userrole" already exists`

Ocorre quando o banco já contém o ENUM criado manualmente pelo `init_db.py` legado. Esse script **não deve mais ser usado** — o ENUM é gerenciado exclusivamente pelas migrations.

**Solução:** recriar o banco do zero:

```bash
docker compose down -v   # apaga o container e o volume de dados
docker compose up -d
alembic upgrade head
python scripts/seed_db.py
```