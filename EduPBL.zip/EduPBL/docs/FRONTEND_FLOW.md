# Fluxo do Frontend — EduPBL

## Stack e configuração

| Item | Valor |
|---|---|
| Framework | React 18 + TypeScript |
| Build | Vite |
| Estilo | TailwindCSS v4 |
| Roteamento | React Router v6 |
| HTTP | Axios (`src/shared/services/api.ts`) |
| Estado servidor | React Query (`@tanstack/react-query`) |
| Variável de ambiente | `VITE_API_URL` (ex.: `http://localhost:8000`) |

---

## 1. Ponto de entrada — `src/main.tsx`

```
StrictMode
  └── ThemeProvider          (contexto de tema claro/escuro)
       └── BrowserRouter
            └── AuthProvider  (instancia e fornece o QueryClient)
                 └── AppBootstrap  (bloqueia rotas até sessão estar resolvida)
                      └── AppRoutes
```

### O que cada camada faz

| Componente | Responsabilidade |
|---|---|
| `ThemeProvider` | Gerencia `dark`/`light` via `ThemeContext`; persiste em `localStorage` |
| `AuthProvider` | Instancia o `QueryClient` e injeta `QueryClientProvider` em toda a árvore |
| `AppBootstrap` | Chama `useCurrentUser()`; exibe loading enquanto `isBootstrapping = true`; bloqueia render das rotas |
| `AppRoutes` | Define o mapa de rotas com guards |

---

## 2. Bootstrap de autenticação

O bootstrap não é mais um `useEffect` explícito no `AuthProvider` — ele acontece automaticamente quando `useCurrentUser()` é chamado pela primeira vez no `AppBootstrap`. O React Query dispara a query `["me"]`, e o interceptor de 401 tenta o refresh caso o access token não exista ou esteja expirado.

```
AppBootstrap monta
  └── useCurrentUser() → useQuery(["me"])
        └── queryFn: authApi.getCurrentUser()
              ├── GET /auth/me (com access_token em memória, se existir)
              │     ├── 200 OK  → retorna UserMe; query["me"] = UserMe
              │     └── 401     → interceptor do Axios tenta POST /auth/refresh_token
              │                        ├── 200 OK → seta novo access_token; repete GET /auth/me
              │                        │              └── 200 OK → retorna UserMe
              │                        └── 401/erro → query retorna null (sem lançar erro)
              └── catch → retorna null (sessão inválida é estado válido, não erro)
```

**Enquanto `isLoading = true`** (primeira carga, sem dado em cache), `AppBootstrap` exibe uma tela de loading e **nenhuma rota é renderizada** — evitando redirects prematuros baseados em `user = null`.

---

## 3. Camada HTTP — `src/shared/services/api.ts`

### Instância Axios

```ts
const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL,
  withCredentials: true,   // envia cookies (refresh_token) automaticamente
});
```

### Token em memória

```ts
let accessToken: string | null = null;
setAccessToken(token)    // armazena em closure — NÃO em localStorage
getAccessToken()         // lê o valor atual
clearAccessToken()       // limpa (ex.: no logout)
```

### Interceptor de requisição

Adiciona `Authorization: Bearer <access_token>` em **todas** as requisições, **exceto**:
- `POST /auth/token` (login)
- `POST /auth/refresh_token` (renovação de token)

---

## 4. Interceptor de resposta (refresh automático) — `authApi.ts`

Em qualquer resposta `401` de endpoint protegido (não `/token`, não `/refresh_token`):

1. Marca a requisição com `_retry = true` (evita loop infinito).
2. Tenta `POST /auth/refresh_token` diretamente via `api.post` (envia o cookie `refresh_token` automaticamente via `withCredentials`).
3. Se sucesso → `setAccessToken(novo_token)` → atualiza o header `Authorization` da requisição original → repete a requisição.
4. Se falha → `clearAccessToken()` → propaga o erro.

> O interceptor está registrado em `authApi.ts` (não em `api.ts`) para ter acesso ao `setAccessToken`/`clearAccessToken` sem criar dependência circular.

---

## 5. Serviço de auth — `src/features/auth/services/authApi.ts`

| Função | Método | Endpoint | Payload enviado | O que faz |
|---|---|---|---|---|
| `authApi.login(credentials)` | POST | `/auth/token` | `application/x-www-form-urlencoded`: `username`, `password` | Recebe `Token`; chama `setAccessToken` |
| `authApi.getCurrentUser()` | GET | `/auth/me` | Header `Authorization: Bearer <token>` | Retorna `UserMe` |
| `authApi.refreshToken()` | POST | `/auth/refresh_token` | Cookie `refresh_token` (HttpOnly, automático) | Recebe novo `Token`; chama `setAccessToken` |
| `authApi.logout()` | POST | `/auth/logout` | — | Pede ao servidor para invalidar o cookie; chama `clearAccessToken` |

---

## 6. Modelos de dados — `src/features/auth/models/`

### `LoginCredentials`
```ts
{ username: string; password: string }
// "username" recebe o e-mail do usuário
```

### `TokenResponse`
```ts
{ access_token: string; token_type: string; must_change_password: boolean }
```

### `UserMe`
```ts
{
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  role: 'student' | 'guardian' | 'teacher' | 'coordinator' | 'porter' | 'admin';
  is_tutor: boolean;
  is_active: boolean;
  classroom_id: number | null;
  must_change_password: boolean;
}
```

---

## 7. AuthContext e QueryClient — `src/features/auth/hooks/AuthContext.tsx`

O `AuthProvider` **não gerencia estado de usuário diretamente** — ele instancia e fornece o `QueryClient`. O usuário vive em `queryClient.getQueryData(["me"])`.

```ts
export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,  // usuário não muda ao focar a janela
      retry: false,                  // 401 não é falha transitória
    },
  },
});
```

O contexto expõe o `queryClient` para casos avançados (via `useAuthContext()`), mas na maioria dos usos os hooks `useCurrentUser`, `useLogin` e `useLogout` são suficientes.

---

## 8. Hooks de autenticação — `src/features/auth/hooks/useAuth.ts`

### `useCurrentUser()`

```ts
const { user, isBootstrapping, isFetching } = useCurrentUser();
```

- Executa `useQuery(["me"])` com `staleTime: Infinity` — o dado nunca fica stale automaticamente; só muda por login/logout explícito.
- `user` → `UserMe | null` (null quando sem sessão ou ainda carregando).
- `isBootstrapping` → derivado de `isLoading` (true apenas na primeira carga sem cache).
- `isFetching` → true em qualquer revalidação posterior.

### `useLogin()`

Retorna `useMutation` com:

```
mutationFn:
  1. authApi.login(credentials)    → POST /auth/token → seta access_token
  2. authApi.getCurrentUser()      → GET /auth/me → retorna UserMe

onSuccess(user):
  queryClient.setQueryData(["me"], user)   ← injeta no cache sem refetch
```

Uso: `const { mutateAsync, isPending } = useLogin();`

### `useLogout()`

Retorna `useMutation` com:

```
mutationFn:
  authApi.logout()                 → POST /auth/logout → servidor remove cookie

onSettled (mesmo em erro):
  clearAccessToken()               ← memória JS limpa
  queryClient.setQueryData(["me"], null)
  queryClient.removeQueries(["me"])
  navigate("/entrar", { replace: true })
```

> `onSettled` garante limpeza mesmo se a chamada ao servidor falhar.

---

## 9. Sistema de rotas — `src/routes/`

### Mapa de rotas (`index.tsx`)

| Caminho | Guard | Componente |
|---|---|---|
| `/` | `SmartRedirect` | `LandingPage` |
| `/entrar` | `PublicOnlyRoute` | `LoginPage` |
| `/cadastrar` | `PublicOnlyRoute` | `SignupPage` |
| `/inicio` | `ProtectedRoutes` | `HomePage` |
| `/ocorrencias` | `ProtectedRoutes` | `OccurrencesPage` |
| `*` | — | `NotFound` |

### Guards

**`ProtectedRoutes`**
- Se `user != null` → renderiza `<Outlet>`.
- Se `user == null` → `<Navigate to="/entrar" replace />`.

**`PublicOnlyRoute`**
- Se `user != null` → `<Navigate to="/inicio" replace />`.
- Se `user == null` → renderiza `<Outlet>`.

**`SmartRedirect`**
- Se `user != null` E é a primeira visita da aba (sem `landing_visited` no `sessionStorage`) → `<Navigate to="/inicio" replace />` e grava a flag.
- Caso contrário → renderiza `<Outlet>` (landing page normalmente).

> **Importante:** os guards **não verificam `isBootstrapping`** diretamente — isso é responsabilidade do `AppBootstrap`, que bloqueia o render de todo o `<AppRoutes>` até o bootstrap terminar.

---

## 10. Componentes de layout — `src/components/layout/`

### `GradientBackdrop`

Fundo de gradiente `from-bg-primary to-bg-accent` com textura opcional do Figma por cima. Usado em `HomePage`, `OccurrencesPage` e demais páginas protegidas.

### `SiteHeader`

Cabeçalho institucional com logo e botão "Entrar" / "Ir para o app" (dependendo do estado de auth). Usado nas páginas públicas.

### `FeatureLayout`

Layout padrão para páginas de features (ex.: Ocorrências, Usuários). Fornece:
- Botão "← Voltar" linkando para `/inicio`.
- Título da feature.
- Barra de tabs de ação (`Listar`, `Criar`, etc.) com estado controlado externamente.
- Área de conteúdo principal (`children`).

```tsx
<FeatureLayout
  title="Ocorrências"
  tabs={[{ id: "listar", label: "Listar" }, { id: "criar", label: "Criar" }]}
  activeTab={activeTab}
  onTabChange={setActiveTab}
>
  {activeTab === "listar" && <OccurrenceList />}
  {activeTab === "criar"  && <OccurrenceForm />}
</FeatureLayout>
```

---

## 11. Componentes de UI — `src/components/ui/`

| Componente | Descrição |
|---|---|
| `Button` | Botão com variantes `primary`, `secondary`, `ghost`, `danger`. Usa CSS variables da paleta. |
| `TextField` | Input com suporte a `label`, `error`, `placeholder`. Border e focus usam `primary`/`accent`. |
| `FeatureCard` | Card clicável (link) para navegar para uma feature. Usa `border`, `surface`, `text` da paleta. Equivalente ao antigo `DashboardActionCard`. |
| `FigmaImage` | Img com fallback para quando a asset do Figma não carregar. |

---

## 12. Paleta de cores — `src/styles/index.css`

Todas as cores são definidas via CSS custom properties e mapeadas como tokens Tailwind via `@theme`. **Nenhum valor hexadecimal hardcoded** deve aparecer nos componentes — usar sempre as classes utilitárias (`text-primary`, `bg-surface`, etc.).

| Token | Light | Dark |
|---|---|---|
| `--primary` | `#166534` | `#34d07f` |
| `--primary-hover` | `#14532d` | `#22c55e` |
| `--secondary` | `#15803d` | `#2f7a4f` |
| `--accent` | `#c9a227` | `#d8bb55` |
| `--bg` | `#f8faf8` | `#111513` |
| `--surface` | `#ffffff` | `#161b18` |
| `--border` | `#e5e7eb` | `#232a26` |
| `--text` | `#111827` | `#f3f4f6` |
| `--text-muted` | `#6b7280` | `#9ca3af` |
| `--danger` | `#dc2626` | `#ef4444` |

---

## 13. Fluxo completo de login

```
[LoginPage] formulário submetido
  └── useLogin().mutateAsync({ username: email, password })
        ├── authApi.login(credentials)
        │     └── POST /auth/token (form-urlencoded)
        │           └── Resposta: Token { access_token, token_type, must_change_password }
        │                 └── setAccessToken(access_token)  ← token salvo em memória JS
        ├── authApi.getCurrentUser()
        │     └── GET /auth/me
        │           └── Resposta: UserMe
        └── onSuccess: queryClient.setQueryData(["me"], user)
              └── navigate('/inicio', { replace: true })   ← feito na LoginPage
```

---

## 14. Fluxo completo de logout

```
[qualquer componente] useLogout().mutate()
  ├── authApi.logout()
  │     └── POST /auth/logout
  │           └── Servidor: delete_cookie('refresh_token')
  └── onSettled (sempre):
        ├── clearAccessToken()              ← memória JS limpa
        ├── queryClient.setQueryData(["me"], null)
        ├── queryClient.removeQueries(["me"])
        └── navigate("/entrar", { replace: true })
```

---

## 15. Onde o ROLE é armazenado

| Dado | Onde | Segurança |
|---|---|---|
| `access_token` | Memória JS (closure em `api.ts`) | ✅ Não persiste entre reloads; não acessível por outras abas |
| `refresh_token` | Cookie `HttpOnly` (`SameSite=none`, `Secure=true`, path restrito a `/auth/refresh_token`) | ✅ Inacessível via JS; enviado apenas no endpoint de refresh |
| `role`, `email`, demais dados | Cache do React Query (`queryClient["me"]`) | ✅ Memória; originam do JWT assinado pelo servidor via `/auth/me` |

O `role` nunca é lido de um cookie — é obtido via `/auth/me` após cada login/bootstrap e mantido no cache do React Query.
