# Fluxo do Backend — EduPBL

## Stack e configuração

| Item | Valor |
|---|---|
| Framework | FastAPI (async) |
| ORM | SQLAlchemy 2 (async) + Alembic |
| Banco | PostgreSQL (asyncpg) |
| Auth | JWT (HS256) via `PyJWT` |
| Hash de senha | `pwdlib` (Argon2) |
| Configuração | `pydantic-settings` (`.env`) |

---

## 1. Inicialização da aplicação — `app/main.py`

```python
app = FastAPI(title='EduPBL', lifespan=lifespan)
```

### Middleware CORS

```python
CORSMiddleware(
    allow_origins=['http://localhost:5173'],
    allow_credentials=True,   # necessário para cookies cross-origin
    allow_methods=['*'],
    allow_headers=['*'],
)
```

> Em produção: `allow_origins` deve listar apenas o domínio real do frontend.

### Lifespan (startup)

Se `ENVIRONMENT == 'development'`:
- Executa `seed_test_users(session)` → cria usuários de teste no banco (salas + usuários de cada role).

### Routers registrados

| Prefixo | Módulo |
|---|---|
| `/auth` | `app.domains.auth.routers` |
| `/users` | `app.domains.users.routers` |
| `/occurrences` | `app.domains.occurrences.routers` |

Também há `GET /` retornando `{ "message": "Olá Mundo!" }` para health check.

---

## 2. Configuração — `app/core/settings.py`

Lida via `pydantic-settings` do arquivo `.env` na raiz do projeto.

| Variável | Padrão | Descrição |
|---|---|---|
| `SECRET_KEY` | `test-secret-key-not-for-production` | Chave de assinatura JWT — **deve ser alterada em produção** |
| `ALGORITHM` | `HS256` | Algoritmo JWT |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | `30` | Validade do access token |
| `REFRESH_TOKEN_EXPIRE_MINUTES` | `43200` | Validade do refresh token (30 dias) |
| `ENVIRONMENT` | `development` | Controla seed de dados de teste |
| `DATABASE_URL` | `postgresql+asyncpg://edupbl:edupbl@localhost:5432/edupbl` | URL de conexão com o banco |
| `ARGON2_MEMORY_COST` | `65536` | Custo de memória do Argon2 |
| `ARGON2_TIME_COST` | `3` | Custo de tempo do Argon2 |
| `API_URL` | `http://localhost:8000/` | URL base da própria API |

### Campos computados

| Campo | Valor atual | Descrição |
|---|---|---|
| `COOKIE_SAME_SITE` | `'none'` (fixo) | Atributo `SameSite` do cookie de refresh |
| `COOKIE_SECURE` | `True` (fixo) | Atributo `Secure` do cookie de refresh |

> **Nota:** os valores `SameSite=none` e `Secure=True` estão fixos no código (não dependem de `ENVIRONMENT`). O código comentado sugere usar `lax`/`False` em desenvolvimento futuramente.

---

## 3. Segurança — `app/shared/security.py`

### Hashing de senha

```python
pwd_context = PasswordHash.recommended()   # Argon2 com parâmetros recomendados
get_password_hash(plain)     → hash
verify_password(plain, hash) → bool
```

### Criação de tokens JWT

Ambos os tokens compartilham a mesma estrutura; diferem apenas na expiração. O tempo é sempre em UTC via `ZoneInfo('UTC')`:

```python
payload = {
    'sub': user.email,   # subject = e-mail do usuário
    'exp': datetime.now(tz=ZoneInfo('UTC')) + timedelta(minutes=...)
}
token = encode(payload, SECRET_KEY, algorithm=ALGORITHM)
```

| Função | Expiração |
|---|---|
| `create_access_token(data)` | `ACCESS_TOKEN_EXPIRE_MINUTES` (padrão: 30 min) |
| `create_refresh_token(data)` | `REFRESH_TOKEN_EXPIRE_MINUTES` (padrão: 30 dias) |

### `oauth2_scheme`

```python
oauth2_scheme = OAuth2PasswordBearer(
    tokenUrl='auth/token', refreshUrl='auth/refresh'
)
```

### Dependência `get_current_user`

Injetada via `Depends` nos endpoints protegidos:

```
Header: Authorization: Bearer <access_token>
  └── OAuth2PasswordBearer extrai o token
        └── decode(token, SECRET_KEY, algorithms=[ALGORITHM])
              ├── Extrai payload['sub'] (e-mail)
              ├── DecodeError / ExpiredSignatureError → 401
              └── SELECT * FROM users WHERE email = sub
                    WITH noload(students, guardians, classroom)
                    ├── Usuário encontrado → retorna User
                    └── Não encontrado → 401
```

> Os relacionamentos (`students`, `guardians`, `classroom`) são carregados com `noload` para evitar lazy-load acidental em contexto async.

---

## 4. Endpoints de autenticação — `app/domains/auth/routers.py`

Constantes de path dos cookies:
```python
ESCOPO_ACCESS_TOKEN  = '/auth/token'
ESCOPO_REFRESH_TOKEN = '/auth/refresh_token'
```

### `POST /auth/token` — Login

**Input (form-urlencoded):**
```
username = <email do usuário>
password = <senha em texto plano>
```

**Processamento:**
1. Busca `User` pelo `email` (`username` no formulário OAuth2).
2. Verifica `verify_password(form_data.password, user.password)`.
3. Cria `access_token` e `refresh_token` com `sub = user.email`.
4. Seta cookie `refresh_token` na resposta:
   ```
   Set-Cookie: refresh_token=<jwt>
     HttpOnly=true
     Secure=true
     SameSite=none
     Path=/auth/refresh_token    ← restrito ao endpoint de renovação
     Max-Age=<REFRESH_TOKEN_EXPIRE_MINUTES × 60>
   ```

**Output (JSON):**
```json
{
  "access_token": "<jwt>",
  "token_type": "bearer",
  "must_change_password": false
}
```

**Erros:** `401` se e-mail não encontrado ou senha incorreta.

---

### `POST /auth/refresh_token` — Renovação de token

**Input:** Cookie `refresh_token` (enviado automaticamente pelo browser via `withCredentials`).

**Processamento:**
1. Lê `request.cookies.get('refresh_token')`.
2. Decodifica e valida o JWT; extrai `payload['sub']` (e-mail).
3. Busca o usuário no banco.
4. Cria novos `access_token` e `refresh_token` (rotação de refresh token).
5. Atualiza o cookie `refresh_token` com o novo token e nova expiração (mesmas flags: `HttpOnly`, `Secure`, `SameSite=none`, `Path=/auth/refresh_token`).

**Output (JSON):**
```json
{
  "access_token": "<novo jwt>",
  "token_type": "bearer",
  "must_change_password": false
}
```

**Erros:** `401` se cookie ausente, token inválido, expirado ou usuário não encontrado.

---

### `POST /auth/logout` — Logout

**Input:** Nenhum payload obrigatório.

**Processamento:**
1. `response.delete_cookie('refresh_token', path='/auth/refresh_token', samesite='none', secure=True, httponly=True)`.
   > O `path` deve bater com o path usado na criação do cookie — sem isso o browser ignora a deleção.

**Output (JSON):**
```json
{ "message": "Logout successful" }
```

---

### `GET /auth/me` — Dados do usuário atual

**Input:** Header `Authorization: Bearer <access_token>`.

**Processamento:**
1. `get_current_user` (dependência) extrai e valida o token, busca o `User` no banco.
2. Serializa com `UserPublic`.

**Output (JSON):**
```json
{
  "id": 1,
  "username": "joao.silva",
  "email": "joao@escola.edu.br",
  "first_name": "João",
  "last_name": "Silva",
  "role": "student",
  "is_tutor": false,
  "is_active": true,
  "classroom_id": 3,
  "must_change_password": false
}
```

**Erros:** `401` se token inválido ou expirado.

---

### `GET /auth/me/permissions` — Dados + permissões

Igual a `/auth/me`, mas inclui também o array `permissions` calculado em `get_user_permissions(user)` com base no `role` (e em `is_tutor` para professores DT).

---

### `GET /auth/admin` — Rota restrita

Requer `role` de `coordinator` ou `admin` (via `role_required`). Retorna `UserPublic` do usuário logado. Usada para testar restrição por role.

---

## 5. Endpoints de usuários — `app/domains/users/routers.py`

| Método | Path | Autenticação | Restrição | Descrição |
|---|---|---|---|---|
| `POST` | `/users/` | Não | — | Cria usuário (cadastro público) |
| `GET` | `/users/` | Sim | Qualquer usuário logado | Lista usuários com paginação (`offset`, `limit`) |
| `PUT` | `/users/{user_id}` | Sim | Apenas o próprio usuário | Atualização parcial (todos campos opcionais) |
| `PATCH` | `/users/me/password` | Sim | Apenas o próprio usuário | Troca de senha; limpa `must_change_password` |
| `DELETE` | `/users/{user_id}` | Sim | Apenas o próprio usuário | Remove usuário |

**Notas:**
- `POST /users/` verifica conflito de `username` e `email` antes de criar; retorna `409` em caso de duplicata.
- `PUT /users/{user_id}` também valida conflito de `username`/`email` ao atualizar.
- A senha é sempre hasheada com Argon2 antes de persistir.
- `PUT` e `DELETE` usam `current_user.id != user_id` como guard de autorização (403 se diferente).

---

## 6. Endpoints de ocorrências — `app/domains/occurrences/routers.py`

| Método | Path | Permissão requerida | Restrição extra | Descrição |
|---|---|---|---|---|
| `POST` | `/occurrences/` | `OCCURRENCES_CREATE` | — | Cria ocorrência; `created_by_id` = usuário logado |
| `GET` | `/occurrences/` | `OCCURRENCES_VIEW_ALL` | — | Lista todas as ocorrências |
| `GET` | `/occurrences/me` | `OCCURRENCES_VIEW_OWN` | Aluno: `student_id == me`; outros: `created_by_id == me` | Lista ocorrências do próprio usuário |
| `GET` | `/occurrences/{id}` | `OCCURRENCES_VIEW_OWN` | Aluno só vê a própria; outros veem qualquer | Retorna ocorrência por ID |
| `PUT` | `/occurrences/{id}` | `OCCURRENCES_EDIT` | Professor só edita as que criou | Atualização parcial |
| `DELETE` | `/occurrences/{id}` | `OCCURRENCES_DELETE` | Professor só deleta as que criou | Remove ocorrência |

**Modelo `Occurrence`:**
```
id              PK
student_id      FK → users.id (CASCADE DELETE)
title           String(200)
description     Text
created_by_id   FK → users.id (SET NULL se deletado)
created_at      datetime (server_default)
updated_at      datetime (server_default, onupdate)
```

> Nenhum `relationship` é mantido no modelo `Occurrence` — um bug do SQLAlchemy 2.x com `mapped_as_dataclass` faz com que `noload` de relationships redefina FKs para `None` após `session.refresh()`. Os endpoints usam apenas os campos escalares (`student_id`, `created_by_id`).

---

## 7. RBAC — `app/shared/rbac/`

### Roles (`roles.py`)

```python
class UserRole(str, Enum):
    STUDENT     = 'student'
    GUARDIAN    = 'guardian'
    TEACHER     = 'teacher'
    COORDINATOR = 'coordinator'
    PORTER      = 'porter'
    ADMIN       = 'admin'
```

### Permissões (`permissions.py`)

Domínios cobertos: `certificates`, `delays`, `occurrences`, `reports`, `spaces`, `suggestions`, `user`.

Domínios planejados (comentados como "Falta Implementar"): `delays`, `certificates`, `spaces`, `reports`, `suggestions`.

**Permissões por role:**

| Role | Permissões base |
|---|---|
| `STUDENT` | `occurrences:read_own`, `delays:read_own`, `certificates:submit` |
| `GUARDIAN` | `user:read_child`, `occurrences:read_child`, `delays:read_child`, `certificates:submit` |
| `TEACHER` | `occurrences:create/delete/update/read_own`, `spaces:reservate/read_all` |
| `COORDINATOR` | Todas as permissões exceto `user:change_role` |
| `PORTER` | `delays:create`, `delays:read_all` |
| `ADMIN` | Todas as permissões |

**Permissões universais** (adicionadas a todos os roles):
- `user:update` (editar os próprios dados)
- `suggestions:submit`
- `user:read_own`

**Permissões extras para Professor DT** (`is_tutor=True AND role=TEACHER`):
- `certificates:validate`
- `reports:view_OWN_CLASSROOM`

> A flag `is_tutor` só confere permissões extras se combinada com `role=TEACHER`. Um aluno ou outro role com `is_tutor=True` não recebe esses extras.

### Dependências (`dependencies.py`)

| Dependência | Uso |
|---|---|
| `role_required([UserRole.X, ...])` | Garante que `user.role` está na lista; retorna `User` ou lança `403` |
| `PermissionChecker({Perm.X, ...})` | Verifica se o usuário tem **todas** as permissões listadas; lança `403` se não |
| `require_permission(user, perm)` | Helper síncrono — retorna `bool`; não lança exceção |
| `require_any_permission(user, perm)` | Retorna `bool`; verdadeiro se tiver qualquer uma |
| `require_all_permissions(user, perms)` | Retorna `bool`; verdadeiro se tiver todas |

Ambas as dependências injetam `get_current_user` internamente (requerem `Authorization` válido).

---

## 8. Modelo de usuário — `app/domains/users/models.py`

### Tabela `classrooms`

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | Integer PK | Auto-incremento |
| `name` | String(50) unique | Ex.: "1º ano A", "2º ano B" |

12 salas padrão criadas pelo seed (1º ao 3º ano, turmas A–D).

### Tabela `users`

| Campo | Tipo | Descrição |
|---|---|---|
| `id` | Integer PK | Auto-incremento |
| `username` | String(50) unique | Apenas `[a-z0-9_.]` (validado por `field_validator`) |
| `email` | String(255) unique | Usado como `sub` no JWT |
| `password` | String | Hash Argon2 |
| `first_name` | String(100) | Nome |
| `last_name` | String(100) | Sobrenome |
| `role` | Enum `UserRole` | Papel no sistema (default: `student`) |
| `is_tutor` | Boolean | Professor Diretor de Turma (default: `False`) |
| `is_active` | Boolean | Conta ativa (default: `True`) |
| `must_change_password` | Boolean | Força troca no 1º login (default: `False`) |
| `classroom_id` | FK → `classrooms.id` (SET NULL) | Nulo para não-alunos |
| `created_at` / `updated_at` | DateTime | `server_default=func.now()` |

### Tabela de associação `guardian_student` (M×N)

| Campo | Tipo |
|---|---|
| `guardian_id` | FK → `users.id` (CASCADE DELETE) |
| `student_id` | FK → `users.id` (CASCADE DELETE) |

### Relacionamentos (todos `lazy='noload'`)

| Relação | Direção | Descrição |
|---|---|---|
| `students` | Guardian → User[] | Alunos vinculados ao responsável |
| `guardians` | User → Guardian[] | Responsáveis do aluno |
| `classroom` | User → Classroom | Sala do usuário |

---

## 9. Schemas Pydantic — `app/domains/users/schemas.py`

| Schema | Campos | Uso |
|---|---|---|
| `UserSchema` | Todos os campos + validação de `username` via `field_validator` | Criação de usuário (`POST /users/`) |
| `UserUpdate` | Todos opcionais + validação de `username` | Atualização parcial (`PUT /users/{id}`) |
| `UserPublic` | Campos públicos (sem `password`); `model_config = ConfigDict(from_attributes=True)` | Output de `/auth/me` e demais GETs |
| `UserWithPermissions` | `UserPublic` + `permissions: set[SystemPermissions]` | Output de `/auth/me/permissions` |
| `PasswordChange` | `current_password`, `new_password` | Troca de senha (`PATCH /users/me/password`) |
| `UserList` | `users: list[UserPublic]` | Output de `GET /users/` |
| `FilterPage` | `offset: int (≥0)`, `limit: int (1–100)` | Query params de paginação |
| `Message` | `message: str` | Respostas genéricas de sucesso |

---

## 10. Seed de dados — `app/shared/db/seed.py`

### Seed de desenvolvimento (`seed_test_users`)

Cria salas (12 turmas) e um usuário de teste para cada role. Idempotente — pula se o email já existir.

| username | email | senha | role | is_tutor | classroom |
|---|---|---|---|---|---|
| `admin` | admin@edupbl.com | admin | ADMIN | False | — |
| `coordenador` | coordenador@edupbl.com | coordenador | COORDINATOR | False | — |
| `professor` | professor@edupbl.com | professor | TEACHER | False | — |
| `professor_dt` | professor_dt@edupbl.com | professor_dt | TEACHER | **True** | 1º ano A |
| `porteiro` | porteiro@edupbl.com | porteiro | PORTER | False | — |
| `aluno` | aluno@edupbl.com | aluno | STUDENT | False | 1º ano A |
| `responsavel` | responsavel@edupbl.com | responsavel | GUARDIAN | False | — |

### Seed de produção (`seed_real_users`)

Importa usuários a partir de CSVs em `data/`. Arquivos esperados: `admins.csv`, `coordenadores.csv`, `professores.csv`, `professores_dt.csv`, `alunos.csv`, `porteiros.csv`, `responsaveis.csv`.

Colunas CSV: `nome`, `sobrenome`, `email`, `senha`, `role` (opcional), `sala` (opcional, para alunos e DTs).

Gera `username` único automaticamente no padrão `primeiro.ultimo` (sem acentos), com sufixo numérico em caso de conflito. Usa `must_change_password=True` para todos os importados.

---

## 11. Fluxo completo de uma requisição protegida

```
Cliente → GET /occurrences
  Header: Authorization: Bearer <access_token>
    │
    ├── Middleware CORS valida origem
    │
    └── Router de occurrences
          └── Depends(PermissionChecker({OCCURRENCES_VIEW_ALL}))
                └── Depends(get_current_user)
                      ├── OAuth2PasswordBearer extrai token do header
                      ├── decode(token)  →  { sub: "email@escola.br", exp: ... }
                      ├── SELECT User WHERE email = sub (noload relationships)
                      └── Retorna User
                            └── PermissionChecker verifica permissão
                                  └── Handler executa a lógica de negócio
                                        └── Resposta 200 com dados
```

Se o token estiver expirado: `401` → frontend intercepta → chama `/auth/refresh_token` com o cookie → recebe novo token → repete a requisição.

---

## 12. Onde o ROLE é armazenado e validado

| Local | O quê | Como |
|---|---|---|
| Banco de dados | `users.role` (Enum) | Fonte de verdade |
| JWT `access_token` | **Não está no JWT** — apenas `sub` (email) | Token carrega só o identificador |
| `/auth/me` response | `role` no JSON | Lido pelo frontend após login/bootstrap |
| Verificação em endpoints | `user.role` (carregado do banco via `get_current_user`) | `role_required(...)` ou `PermissionChecker(...)` |

> O `role` é sempre verificado **contra o banco** (via `get_current_user`), não contra o JWT — uma mudança de role tem efeito imediato na próxima requisição, sem precisar invalidar tokens.
