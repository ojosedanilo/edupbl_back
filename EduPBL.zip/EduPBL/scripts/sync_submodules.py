#!/usr/bin/env python3
"""
Sincroniza os submódulos do EduPBL com o repositório raiz.

Agora respeita a branch atual (main, develop, etc.)
e evita problemas com detached HEAD e upstream.

Uso
---
python scripts/sync_submodules.py
"""

import os
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def run(cmd, cwd=None, check=True):
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if check and result.returncode != 0:
        print(f"\n❌ Erro: {' '.join(cmd)}")
        print(result.stderr)
        exit(1)
    return result.stdout.strip()


def get_submodules():
    gitmodules = ROOT / ".gitmodules"
    if not gitmodules.exists():
        return []

    output = run(
        ["git", "config", "--file", str(gitmodules), "--get-regexp", "path"],
        check=False,
    )
    if not output:
        return []

    return [line.split()[-1] for line in output.splitlines()]


def get_current_branch(repo):
    try:
        branch = run(["git", "branch", "--show-current"], cwd=repo)
        if branch:
            return branch
    except Exception:
        pass

    return None  # detached


def ensure_branch(repo):
    branch = get_current_branch(repo)

    if branch:
        return branch

    print("   ⚠️ Detached HEAD detectado")

    # tenta recuperar branch mais provável
    try:
        branch = run(
            ["git", "rev-parse", "--abbrev-ref", "origin/HEAD"],
            cwd=repo,
        ).split("/")[-1]

        print(f"   🔧 Restaurando para branch {branch}")
        run(["git", "checkout", branch], cwd=repo)
        return branch

    except Exception:
        print("   ❌ Não foi possível determinar branch automaticamente")
        exit(1)


def ensure_upstream(repo, branch):
    try:
        run(
            ["git", "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{u}"],
            cwd=repo,
        )
    except SystemExit:
        print(f"   🔗 Configurando upstream origin/{branch}")
        run(["git", "push", "-u", "origin", branch], cwd=repo)


def get_commit(repo):
    return run(["git", "rev-parse", "--short", "HEAD"], cwd=repo)


def get_super_commit(path):
    try:
        return run(["git", "ls-tree", "HEAD", path], cwd=ROOT).split()[2][:7]
    except Exception:
        return None


def get_status(repo):
    return run(["git", "status", "--porcelain"], cwd=repo)


def get_ahead_behind(repo, branch):
    try:
        run(["git", "fetch"], cwd=repo)
        output = run(
            ["git", "rev-list", "--left-right", "--count", f"HEAD...origin/{branch}"],
            cwd=repo,
        )
        ahead, behind = map(int, output.split())
        return ahead, behind
    except Exception:
        return None, None


def sync_submodule(path):
    repo = ROOT / path
    print(f"\n🔄 {path}")

    branch = ensure_branch(repo)
    ensure_upstream(repo, branch)

    old_commit = get_super_commit(path)
    current_commit = get_commit(repo)

    print(f"   🌿 Branch: {branch}")
    print(f"   📌 Antes: {old_commit or 'N/A'}")
    print(f"   📌 Agora: {current_commit}")

    # Status local
    status = get_status(repo)
    if status:
        print("   ✏️ Mudanças locais detectadas → commitando")
        run(["git", "add", "."], cwd=repo)
        run(["git", "commit", "-m", "auto: sync"], cwd=repo)

    # Divergência
    ahead, behind = get_ahead_behind(repo, branch)
    if ahead is not None:
        if behind > 0:
            print(f"   ⚠️ {behind} commits atrás do remoto (pull recomendado)")
        if ahead > 0:
            print(f"   🚀 {ahead} commits à frente → push necessário")

    # Push seguro
    run(["git", "push", "origin", branch], cwd=repo)

    new_commit = get_commit(repo)

    if old_commit and old_commit != new_commit:
        print(f"   ✅ Atualizado: {old_commit} → {new_commit}")
    else:
        print("   ✔ Sem mudança de commit")

    return old_commit, new_commit


def main():
    os.chdir(ROOT)

    print("🔧 Garantindo inicialização dos submódulos...")
    run(["git", "submodule", "update", "--init", "--recursive"])

    root_branch = ensure_branch(ROOT)
    ensure_upstream(ROOT, root_branch)

    submodules = get_submodules()

    if not submodules:
        print("❌ Nenhum submódulo encontrado")
        return

    print("📦 Submódulos encontrados:", ", ".join(submodules))

    changes = []

    for sub in submodules:
        if not (ROOT / sub).is_dir():
            print(f"\n❌ Pasta não encontrada: {sub}")
            continue

        old, new = sync_submodule(sub)

        if old != new:
            changes.append((sub, new))

    if not changes:
        print("\n✔ Nenhuma atualização necessária no repo principal")
        return

    print("\n📦 Atualizando repo principal...")

    for sub, _ in changes:
        run(["git", "add", sub], cwd=ROOT)

    msg = "sync: " + " ".join(f"{sub}@{commit}" for sub, commit in changes)

    run(["git", "commit", "-m", msg], cwd=ROOT)
    run(["git", "push", "origin", root_branch], cwd=ROOT)

    print("\n✅ Commit criado:")
    print(f"   {msg}")


if __name__ == "__main__":
    main()
