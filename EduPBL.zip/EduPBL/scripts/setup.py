#!/usr/bin/env python3
"""
Setup do projeto EduPBL.

Clona os submódulos (frontend e backend) a partir da URL do repositório
raiz substituindo o nome, instala dependências e copia os .env.example.

Uso
---
python scripts/setup.py              # configura frontend e backend
python scripts/setup.py --backend    # só o backend
python scripts/setup.py --frontend   # só o frontend
python scripts/setup.py --no-deps    # clona mas não instala dependências

O script detecta automaticamente a URL do remote 'origin' do repo raiz e
deriva os endereços dos submódulos trocando o nome do repositório:
    .../edupbl.git  →  .../edupbl_front.git
    .../edupbl.git  →  .../edupbl_back.git
"""

import argparse
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────


class Colors:
    RESET = "\033[0m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    CYAN = "\033[36m"


def c(color: str, msg: str) -> str:
    return f"{color}{msg}{Colors.RESET}"


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> str:
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if check and result.returncode != 0:
        print(c(Colors.RED, f"❌ Erro ao executar: {' '.join(cmd)}"))
        if result.stderr.strip():
            print(c(Colors.RED, result.stderr.strip()))
        sys.exit(1)
    return result.stdout.strip()


def cmd_exists(name: str) -> bool:
    result = subprocess.run(
        ["which", name] if platform.system() != "Windows" else ["where", name],
        capture_output=True,
    )
    return result.returncode == 0


# ─────────────────────────────────────────────
# URL derivation
# ─────────────────────────────────────────────


def get_root_remote_url() -> str:
    """Retorna a URL do remote 'origin' do repositório raiz."""
    try:
        url = run(["git", "remote", "get-url", "origin"], cwd=ROOT)
        return url
    except SystemExit:
        print(
            c(
                Colors.YELLOW,
                "⚠️  Não foi possível detectar o remote 'origin'. "
                "Usando URLs do .gitmodules como fallback.",
            )
        )
        return ""


def derive_submodule_url(root_url: str, suffix: str) -> str:
    """
    Dado:
      root_url = https://github.com/ojosedanilo/edupbl.git
      suffix   = _front
    Retorna:
      https://github.com/ojosedanilo/edupbl_front.git

    Funciona para URLs HTTPS e SSH.
    """
    # Remove .git se presente
    base = root_url.rstrip("/")
    if base.endswith(".git"):
        base = base[:-4]

    # Pega o nome do repo (última parte do caminho)
    repo_name = base.split("/")[-1].split(":")[-1]
    parent = base[: -(len(repo_name))]

    return f"{parent}{repo_name}{suffix}.git"


def get_gitmodules_url(path_name: str) -> str:
    """Lê a URL de um submódulo diretamente do .gitmodules."""
    gitmodules = ROOT / ".gitmodules"
    if not gitmodules.exists():
        return ""

    result = subprocess.run(
        [
            "git",
            "config",
            "--file",
            str(gitmodules),
            f"submodule.{path_name}.url",
        ],
        capture_output=True,
        text=True,
        cwd=ROOT,
    )
    return result.stdout.strip()


# ─────────────────────────────────────────────
# Submodule setup
# ─────────────────────────────────────────────


def clone_submodule(name: str, url: str, target: Path) -> bool:
    """Clona o submódulo se a pasta estiver vazia."""
    if target.exists() and any(target.iterdir()):
        print(c(Colors.CYAN, f"   ✔ {name}/ já existe, pulando clone."))
        return False

    print(c(Colors.CYAN, f"   🔗 Clonando {name} de {url} ..."))
    target.mkdir(parents=True, exist_ok=True)
    run(["git", "clone", url, str(target)])
    print(c(Colors.GREEN, f"   ✅ {name} clonado com sucesso."))
    return True


def register_submodule(name: str, path: str, url: str):
    """Garante que o submódulo está registrado no .git/config do root."""
    result = subprocess.run(
        ["git", "config", f"submodule.{name}.url"],
        cwd=ROOT,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        print(c(Colors.CYAN, f"   📌 Registrando submódulo {name} no git config..."))
        run(["git", "submodule", "init"], cwd=ROOT, check=False)
        run(
            ["git", "config", f"submodule.{name}.url", url],
            cwd=ROOT,
        )


def copy_env(target: Path):
    """Copia .env.example para .env se não existir."""
    env_example = target / ".env.example"
    env_file = target / ".env"

    if env_file.exists():
        print(c(Colors.CYAN, "   ✔ .env já existe, pulando."))
        return

    if env_example.exists():
        import shutil

        shutil.copy(env_example, env_file)
        print(
            c(
                Colors.GREEN,
                "   ✅ .env criado a partir de .env.example. "
                "⚠️  Lembre-se de preencher as variáveis!",
            )
        )
    else:
        print(c(Colors.YELLOW, "   ⚠️  .env.example não encontrado."))


def setup_backend(target: Path, install_deps: bool):
    print(c(Colors.GREEN, "\n🚀 Configurando backend..."))

    if not cmd_exists("uv"):
        print(
            c(
                Colors.RED,
                "❌ 'uv' não encontrado. Instale em https://docs.astral.sh/uv/",
            )
        )
        sys.exit(1)

    copy_env(target)

    if install_deps:
        print(c(Colors.CYAN, "   📦 Instalando dependências Python (uv sync)..."))
        run(["uv", "sync"], cwd=target)
        print(c(Colors.GREEN, "   ✅ Dependências instaladas."))
    else:
        print(c(Colors.YELLOW, "   ⏭️  Instalação de dependências pulada (--no-deps)."))

    print(c(Colors.GREEN, "✅ Backend configurado!"))
    print(
        c(
            Colors.YELLOW,
            "\n💡 Próximos passos do backend:\n"
            "   1. Preencha backend/.env\n"
            "   2. docker compose up -d          # sobe o PostgreSQL\n"
            "   3. cd backend && alembic upgrade head\n"
            "   4. uv run python scripts/seed_db.py --tests  # dados de teste\n"
            "      uv run python scripts/seed_db.py         # dados reais\n"
            "   5. task run  (ou python run_all.py)",
        )
    )


def setup_frontend(target: Path, install_deps: bool):
    print(c(Colors.BLUE, "\n⚡ Configurando frontend..."))

    if not cmd_exists("pnpm"):
        print(
            c(
                Colors.RED,
                "❌ 'pnpm' não encontrado. Instale em https://pnpm.io/installation",
            )
        )
        sys.exit(1)

    copy_env(target)

    if install_deps:
        print(c(Colors.CYAN, "   📦 Instalando dependências Node (pnpm install)..."))
        run(["pnpm", "install"], cwd=target)
        print(c(Colors.GREEN, "   ✅ Dependências instaladas."))
    else:
        print(c(Colors.YELLOW, "   ⏭️  Instalação de dependências pulada (--no-deps)."))

    print(c(Colors.BLUE, "✅ Frontend configurado!"))
    print(
        c(
            Colors.YELLOW,
            "\n💡 Próximos passos do frontend:\n"
            "   1. Preencha frontend/.env (VITE_API_URL=...)\n"
            "   2. pnpm run dev",
        )
    )


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────


def parse_args():
    parser = argparse.ArgumentParser(
        description="Setup do projeto EduPBL (clone submódulos + dependências).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos:\n"
            "  python scripts/setup.py              # frontend + backend\n"
            "  python scripts/setup.py --backend    # só o backend\n"
            "  python scripts/setup.py --frontend   # só o frontend\n"
            "  python scripts/setup.py --no-deps    # sem instalar dependências\n"
        ),
    )
    parser.add_argument(
        "--backend",
        action="store_true",
        help="Configura apenas o backend.",
    )
    parser.add_argument(
        "--frontend",
        action="store_true",
        help="Configura apenas o frontend.",
    )
    parser.add_argument(
        "--no-deps",
        action="store_true",
        dest="no_deps",
        help="Clona os repositórios mas não instala dependências.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    install_deps = not args.no_deps

    # Se nenhum flag específico → faz os dois
    do_backend = args.backend or (not args.backend and not args.frontend)
    do_frontend = args.frontend or (not args.backend and not args.frontend)

    print(c(Colors.CYAN, "\n📦 EduPBL — Setup\n" + "=" * 50))

    root_url = get_root_remote_url()

    # ── Backend ──────────────────────────────
    if do_backend:
        backend_dir = ROOT / "backend"
        if root_url:
            backend_url = derive_submodule_url(root_url, "_back")
        else:
            backend_url = get_gitmodules_url("backend")

        print(c(Colors.CYAN, f"\n🔗 Backend URL: {backend_url}"))
        clone_submodule("backend", backend_url, backend_dir)
        register_submodule("backend", "backend", backend_url)
        setup_backend(backend_dir, install_deps)

    # ── Frontend ─────────────────────────────
    if do_frontend:
        frontend_dir = ROOT / "frontend"
        if root_url:
            frontend_url = derive_submodule_url(root_url, "_front")
        else:
            frontend_url = get_gitmodules_url("frontend")

        print(c(Colors.CYAN, f"\n🔗 Frontend URL: {frontend_url}"))
        clone_submodule("frontend", frontend_url, frontend_dir)
        register_submodule("frontend", "frontend", frontend_url)
        setup_frontend(frontend_dir, install_deps)

    print(c(Colors.GREEN, "\n✨ Setup concluído!\n"))


if __name__ == "__main__":
    main()
