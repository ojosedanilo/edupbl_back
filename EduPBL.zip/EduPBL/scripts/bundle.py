#!/usr/bin/env python3
"""
Cria um bundle ZIP com os arquivos sensíveis do projeto (.env e data/).

Uso
---
python scripts/bundle.py
python scripts/bundle.py -o /caminho/saida.zip
"""

import argparse
import zipfile
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

DEFAULT_OUTPUT = PROJECT_ROOT / "project_secrets_bundle.zip"

INCLUDE_PATHS = [
    PROJECT_ROOT / "frontend" / ".env",
    PROJECT_ROOT / "backend" / ".env",
    PROJECT_ROOT / "backend" / "data",
]


def add_to_zip(zipf: zipfile.ZipFile, path: Path, base_path: Path):
    """Adiciona arquivo ou pasta ao zip mantendo estrutura relativa."""
    if path.is_file():
        arcname = path.relative_to(base_path)
        zipf.write(path, arcname)
        print(f"✔ Arquivo adicionado: {arcname}")

    elif path.is_dir():
        for file in path.rglob("*"):
            if file.is_file():
                arcname = file.relative_to(base_path)
                zipf.write(file, arcname)
                print(f"✔ Arquivo adicionado: {arcname}")

    else:
        print(f"⚠ Ignorado (não existe): {path}")


def create_bundle(output_path: Path, base_path: Path):
    print(f"\n📦 Criando bundle em: {output_path}\n")

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zipf:
        for path in INCLUDE_PATHS:
            add_to_zip(zipf, path, base_path)

    print("\n✅ Bundle criado com sucesso!")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Cria um bundle com .env e dados sensíveis do projeto."
    )
    parser.add_argument(
        "-o",
        "--output",
        type=str,
        default=str(DEFAULT_OUTPUT),
        help="Caminho do arquivo ZIP de saída",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    output_path = Path(args.output).resolve()
    create_bundle(output_path, PROJECT_ROOT)
