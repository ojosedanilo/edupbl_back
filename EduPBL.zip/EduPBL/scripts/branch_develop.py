#!/usr/bin/env python3
"""
Cria a branch 'develop' (ou outra branch) nos submódulos e no repositório
raiz, e atualiza as referências dos submódulos nessa nova branch para
apontarem para o HEAD da branch correspondente em cada submódulo.

Fluxo executado
---------------
1. Para cada submódulo (frontend, backend):
   a. git fetch
   b. Cria a branch <BRANCH> a partir de main (se ainda não existir)
   c. git checkout <BRANCH>
   d. git push -u origin <BRANCH>  (se ainda não existir no remoto)
2. No repositório raiz:
   a. git fetch
   b. Cria a branch <BRANCH> a partir de main (se ainda não existir)
   c. git checkout <BRANCH>
   d. git add frontend backend   (registra os novos commits apontados)
   e. git commit -m "chore: update submodule refs to <BRANCH>"
   f. git push -u origin <BRANCH>

Uso
---
python scripts/branch_develop.py               # branch padrão: develop
python scripts/branch_develop.py --branch feat/x
python scripts/branch_develop.py --no-push     # não faz push no remoto
"""

import argparse
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_BRANCH = "develop"
BASE_BRANCH = "main"


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────


class Colors:
    RESET = "\033[0m"
    GREEN = "\033[32m"
    BLUE = "\033[34m"
    YELLOW = "\033[33m"
    RED = "\033[31m"
    CYAN = "\033[36m"


def c(color: str, msg: str) -> str:
    return f"{color}{msg}{Colors.RESET}"


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> str:
    result = subprocess.run(cmd, cwd=cwd, text=True, capture_output=True)
    if check and result.returncode != 0:
        print(c(Colors.RED, f"❌ Erro: {' '.join(cmd)}"))
        if result.stderr.strip():
            print(c(Colors.RED, result.stderr.strip()))
        sys.exit(1)
    return result.stdout.strip()


def current_branch(repo: Path) -> str:
    return run(["git", "rev-parse", "--abbrev-ref", "HEAD"], cwd=repo)


def branch_exists_local(repo: Path, branch: str) -> bool:
    result = subprocess.run(
        ["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"],
        cwd=repo,
        capture_output=True,
    )
    return result.returncode == 0


def branch_exists_remote(repo: Path, branch: str) -> bool:
    result = subprocess.run(
        ["git", "show-ref", "--verify", "--quiet", f"refs/remotes/origin/{branch}"],
        cwd=repo,
        capture_output=True,
    )
    return result.returncode == 0


def get_submodules() -> list[str]:
    gitmodules = ROOT / ".gitmodules"
    if not gitmodules.exists():
        return []
    output = subprocess.run(
        ["git", "config", "--file", str(gitmodules), "--get-regexp", "path"],
        capture_output=True,
        text=True,
        cwd=ROOT,
    )
    if output.returncode != 0 or not output.stdout.strip():
        return []
    return [line.split()[-1] for line in output.stdout.strip().splitlines()]


# ─────────────────────────────────────────────
# Core
# ─────────────────────────────────────────────


def prepare_submodule(path: str, branch: str, push: bool) -> bool:
    """
    Cria a branch no submódulo e faz checkout.
    Retorna True se o HEAD mudou (commit apontado alterado).
    """
    repo = ROOT / path

    if not repo.is_dir() or not (repo / ".git").exists():
        print(c(Colors.YELLOW, f"   ⚠️  {path}/ não é um repo git válido — pulando."))
        return False

    print(c(Colors.CYAN, f"\n🔧 Submódulo: {path}"))

    # Salva o commit antes
    commit_before = run(["git", "rev-parse", "HEAD"], cwd=repo)

    # Fetch
    print("   📡 git fetch...")
    run(["git", "fetch", "--prune"], cwd=repo)

    # Cria branch local se não existir
    if branch_exists_local(repo, branch):
        print(c(Colors.CYAN, f"   ✔ Branch '{branch}' já existe localmente."))
    else:
        # Tenta usar a remota como base; senão usa BASE_BRANCH
        base = f"origin/{branch}" if branch_exists_remote(repo, branch) else BASE_BRANCH
        print(c(Colors.CYAN, f"   🌿 Criando '{branch}' a partir de {base}..."))
        run(["git", "checkout", "-b", branch, base], cwd=repo)

    # Checkout
    if current_branch(repo) != branch:
        run(["git", "checkout", branch], cwd=repo)

    print(c(Colors.GREEN, f"   ✅ Em branch '{branch}'."))

    # Push
    if push:
        if branch_exists_remote(repo, branch):
            print(c(Colors.CYAN, "   📤 Branch remota já existe — pull antes de push..."))
            run(["git", "pull", "--rebase", "origin", branch], cwd=repo, check=False)
        print(c(Colors.CYAN, f"   📤 Push origin/{branch}..."))
        run(["git", "push", "-u", "origin", branch], cwd=repo)

    commit_after = run(["git", "rev-parse", "HEAD"], cwd=repo)
    return commit_before != commit_after


def prepare_root(branch: str, submodules: list[str], push: bool):
    """Cria a branch no root e commita as referências atualizadas dos submódulos."""
    print(c(Colors.GREEN, "\n📦 Repositório raiz"))

    # Fetch
    print("   📡 git fetch...")
    run(["git", "fetch", "--prune"], cwd=ROOT)

    if branch_exists_local(ROOT, branch):
        print(c(Colors.CYAN, f"   ✔ Branch '{branch}' já existe localmente."))
        if current_branch(ROOT) != branch:
            run(["git", "checkout", branch], cwd=ROOT)
    else:
        base = f"origin/{branch}" if branch_exists_remote(ROOT, branch) else BASE_BRANCH
        print(c(Colors.CYAN, f"   🌿 Criando '{branch}' a partir de {base}..."))
        run(["git", "checkout", "-b", branch, base], cwd=ROOT)

    print(c(Colors.GREEN, f"   ✅ Em branch '{branch}'."))

    # Registra as novas referências dos submódulos
    print("   📌 Atualizando referências dos submódulos...")
    for sub in submodules:
        run(["git", "add", sub], cwd=ROOT)

    # Verifica se há algo a commitar
    status = run(["git", "status", "--porcelain"], cwd=ROOT)
    if status:
        msg = f"chore: update submodule refs to {branch}"
        run(["git", "commit", "-m", msg], cwd=ROOT)
        print(c(Colors.GREEN, f"   ✅ Commit criado: '{msg}'"))
    else:
        print(c(Colors.CYAN, "   ✔ Nada a commitar no root (referências já atualizadas)."))

    if push:
        if branch_exists_remote(ROOT, branch):
            run(["git", "pull", "--rebase", "origin", branch], cwd=ROOT, check=False)
        print(c(Colors.CYAN, f"   📤 Push origin/{branch}..."))
        run(["git", "push", "-u", "origin", branch], cwd=ROOT)
        print(c(Colors.GREEN, "   ✅ Root atualizado no remoto."))


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────


def parse_args():
    parser = argparse.ArgumentParser(
        description="Cria branch em submódulos + root e sincroniza as referências.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exemplos:\n"
            "  python scripts/branch_develop.py\n"
            "  python scripts/branch_develop.py --branch release/v1\n"
            "  python scripts/branch_develop.py --no-push\n"
        ),
    )
    parser.add_argument(
        "--branch",
        default=DEFAULT_BRANCH,
        help=f"Nome da branch a criar (padrão: {DEFAULT_BRANCH}).",
    )
    parser.add_argument(
        "--no-push",
        action="store_true",
        dest="no_push",
        help="Não faz push para o remoto.",
    )
    return parser.parse_args()


def main():
    args = parse_args()
    branch = args.branch
    push = not args.no_push

    os.chdir(ROOT)

    print(c(Colors.CYAN, f"\n🌿 EduPBL — Criar branch '{branch}'\n" + "=" * 50))

    submodules = get_submodules()
    if not submodules:
        print(c(Colors.RED, "❌ Nenhum submódulo encontrado."))
        sys.exit(1)

    print(f"📂 Submódulos: {', '.join(submodules)}")

    for sub in submodules:
        prepare_submodule(sub, branch, push)

    prepare_root(branch, submodules, push)

    print(
        c(
            Colors.GREEN,
            f"\n✨ Branch '{branch}' criada e sincronizada em todos os repositórios!\n",
        )
    )
    print(
        c(
            Colors.YELLOW,
            "💡 Para voltar à main e continuar:\n"
            "   git checkout main\n"
            "   cd frontend && git checkout main\n"
            "   cd ../backend && git checkout main\n",
        )
    )


if __name__ == "__main__":
    main()
