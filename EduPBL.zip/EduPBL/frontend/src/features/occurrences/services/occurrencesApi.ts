import { api } from "@/shared/services/api";

export interface OccurrenceCreate {
  student_id: number;
  title: string;
  description: string;
}

export interface OccurrenceUpdate {
  student_id?: number;
  title?: string;
  description?: string;
}

export interface OccurrencePublic {
  id: number;
  student_id: number;
  created_by_id: number | null;
  title: string;
  description: string;
  created_at: string;
  updated_at: string;
}

export interface OccurrenceList {
  occurrences: OccurrencePublic[];
}

export const occurrencesApi = {
  // Listar todas as ocorrências (coordenador/admin)
  listAll: async (): Promise<OccurrenceList> => {
    const { data } = await api.get<OccurrenceList>("/occurrences");
    return data;
  },

  // Listar minhas ocorrências
  listMine: async (): Promise<OccurrenceList> => {
    const { data } = await api.get<OccurrenceList>("/occurrences/me");
    return data;
  },

  // Buscar uma ocorrência específica
  getById: async (id: number): Promise<OccurrencePublic> => {
    const { data } = await api.get<OccurrencePublic>(`/occurrences/${id}`);
    return data;
  },

  // Criar nova ocorrência
  create: async (occurrence: OccurrenceCreate): Promise<OccurrencePublic> => {
    const { data } = await api.post<OccurrencePublic>(
      "/occurrences",
      occurrence
    );
    return data;
  },

  // Atualizar ocorrência
  update: async (
    id: number,
    occurrence: OccurrenceUpdate
  ): Promise<OccurrencePublic> => {
    const { data } = await api.put<OccurrencePublic>(
      `/occurrences/${id}`,
      occurrence
    );
    return data;
  },

  // Deletar ocorrência
  delete: async (id: number): Promise<void> => {
    await api.delete(`/occurrences/${id}`);
  },
};
