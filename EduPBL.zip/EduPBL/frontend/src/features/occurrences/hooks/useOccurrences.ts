import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { occurrencesApi } from "../services/occurrencesApi";
import type {
  OccurrenceCreate,
  OccurrenceUpdate,
} from "../services/occurrencesApi";

const OCCURRENCES_QUERY_KEY = ["occurrences"] as const;
const MY_OCCURRENCES_QUERY_KEY = ["occurrences", "me"] as const;

export function useOccurrences() {
  return useQuery({
    queryKey: OCCURRENCES_QUERY_KEY,
    queryFn: () => occurrencesApi.listAll(),
  });
}

export function useMyOccurrences() {
  return useQuery({
    queryKey: MY_OCCURRENCES_QUERY_KEY,
    queryFn: () => occurrencesApi.listMine(),
  });
}

export function useOccurrenceById(id: number) {
  return useQuery({
    queryKey: ["occurrences", id],
    queryFn: () => occurrencesApi.getById(id),
  });
}

export function useCreateOccurrence() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: OccurrenceCreate) => occurrencesApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: OCCURRENCES_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: MY_OCCURRENCES_QUERY_KEY });
    },
  });
}

export function useUpdateOccurrence(id: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: OccurrenceUpdate) =>
      occurrencesApi.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: OCCURRENCES_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: ["occurrences", id] });
      queryClient.invalidateQueries({ queryKey: MY_OCCURRENCES_QUERY_KEY });
    },
  });
}

export function useDeleteOccurrence() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: number) => occurrencesApi.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: OCCURRENCES_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: MY_OCCURRENCES_QUERY_KEY });
    },
  });
}
