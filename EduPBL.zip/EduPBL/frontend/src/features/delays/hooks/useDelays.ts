import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { delaysApi } from "../services/delaysApi";
import type { DelayCreate, DelayReject } from "../services/delaysApi";

const DELAYS_QUERY_KEY = ["delays"] as const;
const DELAYS_PENDING_QUERY_KEY = ["delays", "pending"] as const;
const MY_DELAYS_QUERY_KEY = ["delays", "me"] as const;

export function useDelays() {
  return useQuery({
    queryKey: DELAYS_QUERY_KEY,
    queryFn: () => delaysApi.listAll(),
  });
}

export function useDelaysPending() {
  return useQuery({
    queryKey: DELAYS_PENDING_QUERY_KEY,
    queryFn: () => delaysApi.listPending(),
  });
}

export function useMyDelays() {
  return useQuery({
    queryKey: MY_DELAYS_QUERY_KEY,
    queryFn: () => delaysApi.listMine(),
  });
}

export function useDelayById(id: number) {
  return useQuery({
    queryKey: ["delays", id],
    queryFn: () => delaysApi.getById(id),
  });
}

export function useCreateDelay() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: DelayCreate) => delaysApi.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: DELAYS_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: DELAYS_PENDING_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: MY_DELAYS_QUERY_KEY });
    },
  });
}

export function useApproveDelay(id: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => delaysApi.approve(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: DELAYS_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: DELAYS_PENDING_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: ["delays", id] });
    },
  });
}

export function useRejectDelay(id: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: DelayReject) => delaysApi.reject(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: DELAYS_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: DELAYS_PENDING_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: ["delays", id] });
    },
  });
}

export function useUndoDelay(id: number) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => delaysApi.undo(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: DELAYS_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: DELAYS_PENDING_QUERY_KEY });
      queryClient.invalidateQueries({ queryKey: ["delays", id] });
    },
  });
}
