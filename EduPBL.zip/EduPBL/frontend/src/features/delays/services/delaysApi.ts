import { api } from "@/shared/services/api";

export type DelayStatus = "PENDING" | "APPROVED" | "REJECTED";

export interface DelayCreate {
  student_id: number;
  arrival_time: string; // HH:MM format
  reason?: string;
}

export interface DelayApprove {
  // Empty body
}

export interface DelayReject {
  rejection_reason: string;
}

export interface DelayPublic {
  id: number;
  student_id: number;
  registered_by_id: number | null;
  approved_by_id: number | null;
  delay_date: string;
  arrival_time: string;
  expected_time: string;
  delay_minutes: number;
  status: DelayStatus;
  reason: string | null;
  rejection_reason: string | null;
  created_at: string;
  updated_at: string;
}

export interface DelayList {
  delays: DelayPublic[];
}

export const delaysApi = {
  // Listar todos os atrasos
  listAll: async (): Promise<DelayList> => {
    const { data } = await api.get<DelayList>("/delays");
    return data;
  },

  // Listar atrasos pendentes (coordenador/admin)
  listPending: async (): Promise<DelayList> => {
    const { data } = await api.get<DelayList>("/delays/pending");
    return data;
  },

  // Listar meus atrasos (aluno)
  listMine: async (): Promise<DelayList> => {
    const { data } = await api.get<DelayList>("/delays/me");
    return data;
  },

  // Buscar um atraso específico
  getById: async (id: number): Promise<DelayPublic> => {
    const { data } = await api.get<DelayPublic>(`/delays/${id}`);
    return data;
  },

  // Registrar novo atraso
  create: async (delay: DelayCreate): Promise<DelayPublic> => {
    const { data } = await api.post<DelayPublic>("/delays", delay);
    return data;
  },

  // Aprovar atraso
  approve: async (id: number): Promise<DelayPublic> => {
    const { data } = await api.patch<DelayPublic>(
      `/delays/${id}/approve`,
      {}
    );
    return data;
  },

  // Rejeitar atraso
  reject: async (
    id: number,
    rejection: DelayReject
  ): Promise<DelayPublic> => {
    const { data } = await api.patch<DelayPublic>(
      `/delays/${id}/reject`,
      rejection
    );
    return data;
  },

  // Desfazer ação
  undo: async (id: number): Promise<DelayPublic> => {
    const { data } = await api.patch<DelayPublic>(`/delays/${id}/undo`, {});
    return data;
  },
};
