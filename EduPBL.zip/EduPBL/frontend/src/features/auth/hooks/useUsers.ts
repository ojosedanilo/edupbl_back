import { useQuery } from "@tanstack/react-query";
import { usersApi } from "../services/usersApi";

export const useSearchUsers = (query: string, role?: string, limit: number = 10) => {
  return useQuery({
    queryKey: ["users", "search", query, role, limit],
    queryFn: () => usersApi.search(query, role, limit),
    enabled: query.length > 0,
  });
};