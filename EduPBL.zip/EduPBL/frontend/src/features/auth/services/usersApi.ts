import { api } from "@/shared/services/api";

export interface UserPublic {
  id: number;
  username: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  is_active: boolean;
  classroom_id: number | null;
}

export interface UserList {
  users: UserPublic[];
}

export const usersApi = {
  // Buscar usuários por nome (autocomplete)
  search: async (query: string, role?: string, limit: number = 10): Promise<UserList> => {
    const params = new URLSearchParams({ q: query, limit: limit.toString() });
    if (role) params.append('role', role);
    const { data } = await api.get<UserList>(`/users/search?${params}`);
    return data;
  },
};