/**
 * useAvatarUrl
 *
 * Busca o avatar de um usuário via endpoint autenticado e retorna um
 * Object URL utilizável em <img src>.
 *
 * Por que não usar <img src={url}> diretamente?
 *   O endpoint GET /users/{id}/avatar exige o header Authorization,
 *   que browsers não enviam em requisições de imagem nativas.
 *   Este hook usa a instância Axios (que injeta o token em memória)
 *   para buscar a imagem como blob e gerar um Object URL temporário.
 *
 * O Object URL é revogado automaticamente quando o componente desmonta
 * ou quando o userId/avatarKey mudam, evitando vazamento de memória.
 */

import { useEffect, useState } from "react";
import { api } from "@/shared/services/api";

/**
 * @param userId    ID do usuário cujo avatar deve ser carregado.
 * @param avatarKey Incrementar este valor força o recarregamento do avatar
 *                  (útil após upload). Padrão: 0.
 * @param hasAvatar Passar `false` pula a requisição (usuário sem avatar).
 */
export function useAvatarUrl(
  userId: number | null | undefined,
  avatarKey: number = 0,
  hasAvatar: boolean = true,
): string | null {
  const [objectUrl, setObjectUrl] = useState<string | null>(null);

  useEffect(() => {
    if (!userId || !hasAvatar) {
      setObjectUrl(null);
      return;
    }

    let revoked = false;
    let currentUrl: string | null = null;

    api
      .get(`/users/${userId}/avatar`, { responseType: "blob" })
      .then((res) => {
        if (revoked) return;
        const url = URL.createObjectURL(res.data as Blob);
        currentUrl = url;
        setObjectUrl(url);
      })
      .catch(() => {
        if (!revoked) setObjectUrl(null);
      });

    return () => {
      revoked = true;
      if (currentUrl) URL.revokeObjectURL(currentUrl);
    };
  }, [userId, avatarKey, hasAvatar]);

  return objectUrl;
}
