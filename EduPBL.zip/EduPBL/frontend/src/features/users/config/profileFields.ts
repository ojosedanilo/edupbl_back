/**
 * profileFields.ts — Dicionário central de campos do perfil do usuário.
 *
 * Cada entrada descreve como um campo deve ser exibido e se pode ser editado.
 * A UI do ProfilePage lê este arquivo: mudar `editable` aqui reflete
 * imediatamente no formulário, sem tocar nos componentes.
 *
 * Estrutura de um campo:
 *   key        → chave exata em UserMe (tipada)
 *   label      → rótulo exibido ao usuário
 *   group      → agrupa campos em seções na página
 *   editable   → se true, renderiza input; se false, renderiza texto somente-leitura
 *   type       → tipo do <input> (text, email, tel…) ou "static" para somente-leitura
 *   hint       → texto auxiliar exibido abaixo do campo (opcional)
 *   format     → função de formatação para exibição somente-leitura (opcional)
 *
 * ── classroom_id ─────────────────────────────────────────────────────────────
 * O campo classroom_id exibe o NOME da turma em vez do ID numérico.
 * Para isso, ProfilePage deve usar `buildProfileFields(classrooms)` em vez de
 * importar `profileFields` diretamente.
 *
 * Uso no ProfilePage:
 *
 *   const { data: classrooms = [] } = useClassrooms();
 *   const fields = buildProfileFields(classrooms);
 *   // substitui a importação estática de `profileFields`
 */

import type { UserMe } from "@/features/auth/models/UserMe";
import type { Classroom } from "@/features/schedules/services/schedulesApi";

export type FieldKey = keyof UserMe;

export type FieldGroup = "personal" | "account" | "system";

export interface ProfileFieldConfig {
  key: FieldKey;
  label: string;
  group: FieldGroup;
  editable: boolean;
  type: "text" | "email" | "tel" | "static";
  hint?: string;
  format?: (value: UserMe[FieldKey]) => string;
}

// ── Rótulos e formatação ──────────────────────────────────────────────────── //

const roleLabel: Record<string, string> = {
  student: "Aluno(a)",
  guardian: "Responsável",
  teacher: "Professor(a)",
  coordinator: "Coordenador(a)",
  porter: "Porteiro(a)",
  admin: "Administrador(a)",
};

const boolLabel = (v: UserMe[FieldKey]) => (v ? "Sim" : "Não");

const dateLabel = (v: UserMe[FieldKey]) => {
  if (!v) return "—";
  return new Date(v as string).toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "long",
    year: "numeric",
  });
};

// ── Dicionário de campos ──────────────────────────────────────────────────── //
//
// Para tornar um campo editável: mude `editable: false` → `editable: true`.
// Para bloquear um campo: mude `editable: true` → `editable: false`.
// A UI se adapta automaticamente.

/** Campos estáticos que não dependem de dados externos. */
const BASE_FIELDS: ProfileFieldConfig[] = [
  // ── Dados pessoais ──────────────────────────────────────────────────────── //
  {
    key: "first_name",
    label: "Nome",
    group: "personal",
    editable: false, // RESTRITO — altere para true para reativar edição
    type: "text",
  },
  {
    key: "last_name",
    label: "Sobrenome",
    group: "personal",
    editable: false, // RESTRITO — altere para true para reativar edição
    type: "text",
  },
  {
    key: "phone",
    label: "Telefone",
    group: "personal",
    editable: true, // Editável por qualquer usuário (campo de contato pessoal)
    type: "tel",
    hint: "Usado para notificações por WhatsApp/SMS. Ex: +5585999990000",
  },

  // ── Conta ───────────────────────────────────────────────────────────────── //
  {
    key: "username",
    label: "Nome de usuário",
    group: "account",
    editable: false, // RESTRITO — altere para true para reativar edição
    type: "text",
    hint: "Apenas letras minúsculas, números, ponto (.) e underscore (_).",
  },
  {
    key: "email",
    label: "E-mail",
    group: "account",
    editable: false, // RESTRITO — altere para true para reativar edição
    type: "email",
  },

  // ── Informações do sistema (somente leitura) ─────────────────────────────── //
  {
    key: "role",
    label: "Perfil",
    group: "system",
    editable: false,
    type: "static",
    format: (v) => roleLabel[v as string] ?? String(v),
  },
  {
    key: "is_tutor",
    label: "Diretor(a) de Turma",
    group: "system",
    editable: false,
    type: "static",
    format: boolLabel,
  },
  {
    key: "is_active",
    label: "Conta ativa",
    group: "system",
    editable: false,
    type: "static",
    format: boolLabel,
  },
  {
    key: "must_change_password",
    label: "Redefinição de senha pendente",
    group: "system",
    editable: false,
    type: "static",
    format: boolLabel,
  },
  // classroom_id é injetado por buildProfileFields() abaixo
  {
    key: "created_at",
    label: "Membro desde",
    group: "system",
    editable: false,
    type: "static",
    format: dateLabel,
  },
];

/**
 * Constrói a lista completa de campos do perfil, injetando o formatador
 * do campo `classroom_id` com acesso à lista de turmas carregada do servidor.
 *
 * Quando `classrooms` está vazio (ainda carregando), exibe o ID numérico
 * como fallback — sem quebrar a UI.
 *
 * @param classrooms — lista retornada por `useClassrooms()`
 */
export function buildProfileFields(
  classrooms: Classroom[],
): ProfileFieldConfig[] {
  const classroomMap = new Map<number, string>(
    classrooms.map((c) => [c.id, c.name]),
  );

  const classroomField: ProfileFieldConfig = {
    key: "classroom_id",
    label: "Turma",
    group: "system",
    editable: false,
    type: "static",
    format: (v) => {
      if (v == null) return "Sem turma";
      const id = v as number;
      return classroomMap.get(id) ?? `Turma ${id}`;
    },
  };

  // Insere classroom_id na posição correta (antes de created_at)
  const beforeCreatedAt = BASE_FIELDS.slice(0, BASE_FIELDS.length - 1);
  const createdAtField = BASE_FIELDS[BASE_FIELDS.length - 1];

  return [...beforeCreatedAt, classroomField, createdAtField];
}

/**
 * Lista estática sem turmas resolvidas — mantida para compatibilidade com
 * código que não precisa do nome da turma (ex: testes unitários, storybook).
 *
 * Em produção, prefira `buildProfileFields(classrooms)`.
 *
 * @deprecated Use `buildProfileFields(classrooms)` para exibir o nome da turma.
 */
export const profileFields: ProfileFieldConfig[] = buildProfileFields([]);

// ── Grupos organizados para renderização ──────────────────────────────────── //

export const groupMeta: Record<
  FieldGroup,
  { title: string; description: string }
> = {
  personal: {
    title: "Dados pessoais",
    description: "Suas informações de contato e identificação.",
  },
  account: {
    title: "Conta",
    description: "Credenciais de acesso ao sistema.",
  },
  system: {
    title: "Informações do sistema",
    description: "Dados gerenciados pela administração — não editáveis aqui.",
  },
};

export const fieldsByGroup = (
  group: FieldGroup,
  fields: ProfileFieldConfig[] = profileFields,
) => fields.filter((f) => f.group === group);
