/**
 * schedulesApi — Serviço de horários
 *
 * Funções disponíveis:
 *   getPeriods()                     → GET /schedules/periods
 *   getClassroomSchedule(id)         → GET /schedules/classroom/{id}
 *   getTeacherSchedule(id)           → GET /schedules/teacher/{id}
 *   getCurrentTeacher(classroomId)   → GET /schedules/current-teacher/{id}
 *   createSlot(data)                 → POST /schedules/slots
 *   updateSlot(id, data)             → PUT /schedules/slots/{id}
 *   deleteSlot(id)                   → DELETE /schedules/slots/{id}
 *   getOverrides()                   → GET /schedules/overrides
 *   createOverride(data)             → POST /schedules/overrides
 *   deleteOverride(id)               → DELETE /schedules/overrides/{id}
 */

import { api } from "@/shared/services/api";
import type {
  OverrideCreate,
  OverrideList,
  PeriodsList,
  ScheduleOverride,
  ScheduleSlot,
  SlotCreate,
  SlotList,
} from "../models/Schedule";
import type { UserMe } from "@/features/auth/models/UserMe";

/** Turma simplificada para seleção */
export interface Classroom {
  id: number;
  name: string;
}

/** Professor público para listagens */
export interface TeacherPublic {
  id: number;
  first_name: string;
  last_name: string;
  classroom_id: number | null;
}

export interface CurrentLesson {
  in_class: boolean;
  classroom_id?: number;
  period?: {
    name: string;
    type: string;
    start_time: string;
    end_time: string;
  };
  weekday?: number;
}

export const schedulesApi = {
  /** Lista os períodos do dia (aulas + intervalos) em ordem cronológica. */
  getPeriods: async (): Promise<PeriodsList> => {
    const { data } = await api.get<PeriodsList>("/schedules/periods");
    return data;
  },

  /**
   * Retorna todos os slots de horário de uma turma.
   * Requer SCHEDULES_VIEW_OWN | SCHEDULES_VIEW_CHILD | SCHEDULES_VIEW_ALL.
   */
  getClassroomSchedule: async (classroomId: number): Promise<SlotList> => {
    const { data } = await api.get<SlotList>(
      `/schedules/classroom/${classroomId}`,
    );
    return data;
  },

  /**
   * Retorna todos os slots de horário de um professor.
   * Requer SCHEDULES_VIEW_OWN | SCHEDULES_VIEW_ALL.
   * Professores só podem consultar a própria grade.
   */
  getTeacherSchedule: async (userId: number): Promise<SlotList> => {
    const { data } = await api.get<SlotList>(`/schedules/teacher/${userId}`);
    return data;
  },

  /**
   * Retorna o professor que está em aula agora na turma informada.
   * Lança 404 se não houver aula no momento.
   * Requer SCHEDULES_VIEW_OWN | SCHEDULES_VIEW_CHILD | SCHEDULES_VIEW_ALL.
   */
  getCurrentTeacher: async (classroomId: number): Promise<UserMe> => {
    const { data } = await api.get<UserMe>(
      `/schedules/current-teacher/${classroomId}`,
    );
    return data;
  },

  /** Aula atual do professor logado */
  getCurrentLesson: async (): Promise<CurrentLesson> => {
    const { data } = await api.get<CurrentLesson>("/schedules/current-lesson");
    return data;
  },

  /**
   * Cria um novo slot de horário.
   * Requer SCHEDULES_MANAGE.
   */
  createSlot: async (slotData: SlotCreate): Promise<ScheduleSlot> => {
    const { data } = await api.post<ScheduleSlot>("/schedules/slots", slotData);
    return data;
  },

  /**
   * Atualiza um slot de horário existente.
   * Requer SCHEDULES_MANAGE.
   */
  updateSlot: async (
    slotId: number,
    slotData: SlotCreate,
  ): Promise<ScheduleSlot> => {
    const { data } = await api.put<ScheduleSlot>(
      `/schedules/slots/${slotId}`,
      slotData,
    );
    return data;
  },

  /**
   * Remove um slot de horário.
   * Requer SCHEDULES_MANAGE.
   */
  deleteSlot: async (slotId: number): Promise<ScheduleSlot> => {
    const { data } = await api.delete<ScheduleSlot>(
      `/schedules/slots/${slotId}`,
    );
    return data;
  },

  /**
   * Lista todos os overrides (exceções de horário) em ordem decrescente de data.
   * Requer SCHEDULES_VIEW_OWN | SCHEDULES_VIEW_CHILD | SCHEDULES_VIEW_ALL.
   */
  getOverrides: async (): Promise<OverrideList> => {
    const { data } = await api.get<OverrideList>("/schedules/overrides");
    return data;
  },

  /**
   * Cria um novo override de horário.
   * Requer SCHEDULES_MANAGE.
   */
  createOverride: async (
    overrideData: OverrideCreate,
  ): Promise<ScheduleOverride> => {
    const { data } = await api.post<ScheduleOverride>(
      "/schedules/overrides",
      overrideData,
    );
    return data;
  },

  /**
   * Remove um override de horário.
   * Requer SCHEDULES_MANAGE.
   */
  deleteOverride: async (overrideId: number): Promise<ScheduleOverride> => {
    const { data } = await api.delete<ScheduleOverride>(
      `/schedules/overrides/${overrideId}`,
    );
    return data;
  },

  /** Lista todas as turmas (id + name). */
  getClassrooms: async (): Promise<Classroom[]> => {
    const { data } = await api.get<Classroom[]>("/users/classrooms");
    return data;
  },

  /** Lista todos os professores para seleção */
  getAllTeachers: async (): Promise<TeacherPublic[]> => {
    const { data } = await api.get<{ users: TeacherPublic[] }>(
      "/users/?limit=500",
    );

    // Filtrar corretamente
    return data.users.filter((u) => u.classroom_id !== null);
  },
};
