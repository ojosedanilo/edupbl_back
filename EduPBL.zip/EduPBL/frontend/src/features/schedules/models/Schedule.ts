s models
bash

mkdir -p /home/claude/project/frontend/src/features/schedules/{models,services,hooks}

cat > /home/claude/project/frontend/src/features/schedules/models/Schedule.ts << 'EOF'
// Espelho dos schemas do backend: app/domains/schedules/schemas.py

export type WeekdayEnum = 1 | 2 | 3 | 4 | 5 | 6 | 7;

export const WEEKDAY_LABELS: Record<WeekdayEnum, string> = {
  1: "Domingo",
  2: "Segunda-feira",
  3: "Terça-feira",
  4: "Quarta-feira",
  5: "Quinta-feira",
  6: "Sexta-feira",
  7: "Sábado",
};

export type PeriodTypeEnum =
  | "class_period"
  | "planning"
  | "free"
  | "snack_break"
  | "lunch_break";

export interface Period {
  type: PeriodTypeEnum;
  period_number: number | null;
  /** HH:MM:SS */
  start: string;
  /** HH:MM:SS */
  end: string;
}

export interface PeriodsList {
  periods: Period[];
}

export interface ScheduleSlot {
  id: number;
  type: string;
  title: string;
  classroom_id: number;
  teacher_id: number | null;
  weekday: WeekdayEnum;
  period_number: number | null;
}

export interface SlotList {
  slots: ScheduleSlot[];
}

export interface SlotCreate {
  type: string;
  title: string;
  classroom_id: number;
  teacher_id: number | null;
  weekday: WeekdayEnum;
  period_number: number | null;
}

export interface ScheduleOverride {
  id: number;
  title: string;
  override_date: string;
  starts_at: string;
  ends_at: string;
  affects_all: boolean;
  classroom_ids: number[] | null;
  created_at: string;
}

export interface OverrideList {
  overrides: ScheduleOverride[];
}

export interface OverrideCreate {
  title: string;
  override_date: string;
  starts_at: string;
  ends_at: string;
  affects_all: boolean;
  classroom_ids: number[] | null;
}