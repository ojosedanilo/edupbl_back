/**
 * Hooks de horários — React Query
 *
 * usePeriods()                       → useQuery  — lista períodos do dia
 * useClassroomSchedule(classroomId)  → useQuery  — grade de uma turma
 * useTeacherSchedule(userId)         → useQuery  — grade de um professor
 * useCurrentTeacher(classroomId)     → useQuery  — professor em aula agora
 * useCreateSlot()                    → useMutation
 * useUpdateSlot()                    → useMutation
 * useDeleteSlot()                    → useMutation
 * useOverrides()                     → useQuery  — lista de exceções
 * useCreateOverride()                → useMutation
 * useDeleteOverride()                → useMutation
 */

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { schedulesApi } from "../services/schedulesApi";
import type { OverrideCreate, SlotCreate } from "../models/Schedule";

// ── Chaves de cache ───────────────────────────────────────────────────────── //

export const SCHEDULES_KEYS = {
  periods: ["schedules", "periods"] as const,
  classroom: (id: number) => ["schedules", "classroom", id] as const,
  teacher: (id: number) => ["schedules", "teacher", id] as const,
  currentTeacher: (id: number) => ["schedules", "current-teacher", id] as const,
  overrides: ["schedules", "overrides"] as const,

  /** Lista de turmas */
  classrooms: ["schedules", "classrooms"] as const,

  /** Cache combinado de múltiplas turmas */
  allClassroomSchedules: (ids: number[]) =>
    ["schedules", "all-classrooms", ...ids] as const,
};

// ── Períodos ─────────────────────────────────────────────────────────────── //

/** Lista os períodos do dia (aulas + intervalos) em ordem cronológica. */
export function usePeriods() {
  return useQuery({
    queryKey: SCHEDULES_KEYS.periods,
    queryFn: schedulesApi.getPeriods,
    // Períodos raramente mudam — só por deploy; stale de 1 hora
    staleTime: 60 * 60 * 1000,
  });
}

// ── Grade da turma ───────────────────────────────────────────────────────── //

/**
 * Retorna todos os slots de horário de uma turma.
 * Só executa se classroomId for fornecido.
 */
export function useClassroomSchedule(classroomId: number | null | undefined) {
  return useQuery({
    queryKey: SCHEDULES_KEYS.classroom(classroomId ?? 0),
    queryFn: () => schedulesApi.getClassroomSchedule(classroomId!),
    enabled: classroomId != null,
  });
}

// ── Grade do professor ───────────────────────────────────────────────────── //

/**
 * Retorna todos os slots de horário de um professor.
 * Só executa se userId for fornecido.
 */
export function useTeacherSchedule(userId: number | null | undefined) {
  return useQuery({
    queryKey: SCHEDULES_KEYS.teacher(userId ?? 0),
    queryFn: () => schedulesApi.getTeacherSchedule(userId!),
    enabled: userId != null,
  });
}

// ── Professor atual na turma ─────────────────────────────────────────────── //

/**
 * Retorna o professor em aula agora na turma.
 * Refaz a query a cada 5 minutos para manter atualizado.
 * Retorna null (sem erro) se a query retornar 404.
 */
export function useCurrentTeacher(classroomId: number | null | undefined) {
  return useQuery({
    queryKey: SCHEDULES_KEYS.currentTeacher(classroomId ?? 0),
    queryFn: async () => {
      try {
        return await schedulesApi.getCurrentTeacher(classroomId!);
      } catch {
        // 404 = nenhum professor em aula agora — estado válido
        return null;
      }
    },
    enabled: classroomId != null,
    refetchInterval: 5 * 60 * 1000, // re-verifica a cada 5 min
  });
}

// ── Aula atual do professor ──────────────────────────────────────────────── //

/** Aula atual do professor logado */
export const useCurrentLesson = () => {
  return useQuery({
    queryKey: ["schedules", "current-lesson"],
    queryFn: () => schedulesApi.getCurrentLesson(),
  });
};

// ── Turmas ───────────────────────────────────────────────────────────────── //

/**
 * Lista todas as turmas (id + name).
 * Cache longo pois raramente muda.
 */
export function useClassrooms() {
  return useQuery({
    queryKey: SCHEDULES_KEYS.classrooms,
    queryFn: schedulesApi.getClassrooms,
    staleTime: 60 * 60 * 1000,
  });
}

/**
 * Retorna os slots de todas as turmas informadas.
 * Útil para dashboards ou visões agregadas.
 */
export function useAllClassroomSchedules(classroomIds: number[]) {
  return useQuery({
    queryKey: SCHEDULES_KEYS.allClassroomSchedules(classroomIds),

    queryFn: async () => {
      if (classroomIds.length === 0) return [];

      const results = await Promise.all(
        classroomIds.map((id) => schedulesApi.getClassroomSchedule(id)),
      );

      // Garante segurança caso alguma resposta venha inválida
      return results.flatMap((r) => r?.slots ?? []);
    },

    enabled: classroomIds.length > 0,

    // Dados podem mudar ao longo do dia
    staleTime: 5 * 60 * 1000,
  });
}

// ── Mutations: slots ─────────────────────────────────────────────────────── //

/** Cria um slot de horário e invalida o cache da turma correspondente. */
export function useCreateSlot() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: SlotCreate) => schedulesApi.createSlot(data),
    onSuccess: (slot) => {
      queryClient.invalidateQueries({
        queryKey: SCHEDULES_KEYS.classroom(slot.classroom_id),
      });
      if (slot.teacher_id) {
        queryClient.invalidateQueries({
          queryKey: SCHEDULES_KEYS.teacher(slot.teacher_id),
        });
      }
    },
  });
}

/** Atualiza um slot e invalida os caches afetados. */
export function useUpdateSlot() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }: { id: number; data: SlotCreate }) =>
      schedulesApi.updateSlot(id, data),
    onSuccess: (slot) => {
      queryClient.invalidateQueries({
        queryKey: SCHEDULES_KEYS.classroom(slot.classroom_id),
      });
      if (slot.teacher_id) {
        queryClient.invalidateQueries({
          queryKey: SCHEDULES_KEYS.teacher(slot.teacher_id),
        });
      }
    },
  });
}

/** Remove um slot e invalida o cache da turma. */
export function useDeleteSlot() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (slotId: number) => schedulesApi.deleteSlot(slotId),
    onSuccess: (slot) => {
      queryClient.invalidateQueries({
        queryKey: SCHEDULES_KEYS.classroom(slot.classroom_id),
      });
      if (slot.teacher_id) {
        queryClient.invalidateQueries({
          queryKey: SCHEDULES_KEYS.teacher(slot.teacher_id),
        });
      }
    },
  });
}

// ── Overrides ────────────────────────────────────────────────────────────── //

/** Lista todos os overrides de horário. */
export function useOverrides() {
  return useQuery({
    queryKey: SCHEDULES_KEYS.overrides,
    queryFn: schedulesApi.getOverrides,
  });
}

/** Cria um override e invalida a lista. */
export function useCreateOverride() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: OverrideCreate) => schedulesApi.createOverride(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SCHEDULES_KEYS.overrides });
    },
  });
}

/** Remove um override e invalida a lista. */
export function useDeleteOverride() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (overrideId: number) => schedulesApi.deleteOverride(overrideId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: SCHEDULES_KEYS.overrides });
    },
  });
}
