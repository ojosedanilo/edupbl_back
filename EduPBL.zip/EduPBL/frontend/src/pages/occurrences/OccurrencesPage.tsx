import { useState } from "react";
import {
  FeatureLayout,
  type FeatureTab,
} from "@/components/layout/FeatureLayout";
import { OccurrencesTable } from "@/components/dashboard/OccurrencesTableUpdated";
import { OccurrenceForm } from "@/components/dashboard/OccurrenceForm";
import { Modal } from "@/components/ui/Modal";
import { OccurrenceDetail } from "@/components/dashboard/OccurrenceDetail";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import {
  useOccurrences,
  useCreateOccurrence,
  useDeleteOccurrence,
  useOccurrenceById,
} from "@/features/occurrences/hooks/useOccurrences";
import { usePermissions } from "@/features/auth/hooks/usePermissions";

const tabs: FeatureTab[] = [
  { id: "listar", label: "Listar" },
  { id: "criar", label: "Nova ocorrência" },
];

export default function OccurrencesPage() {
  const [activeTab, setActiveTab] = useState<string>("listar");
  const [selectedId, setSelectedId] = useState<number | null>(null);

  const { data: occurrencesData, isLoading: isLoadingList } = useOccurrences();
  const { data: selectedOccurrence, isLoading: isLoadingDetail } =
    useOccurrenceById(selectedId!);
  const createMutation = useCreateOccurrence();
  const deleteMutation = useDeleteOccurrence();
  const { canModerate } = usePermissions();

  const handleCreateOccurrence = async (formData: {
    student_id: number;
    title: string;
    description: string;
  }) => {
    await createMutation.mutateAsync(formData);
    setActiveTab("listar");
  };

  const handleDeleteOccurrence = async (id: number) => {
    if (confirm("Tem certeza que deseja deletar esta ocorrência?")) {
      await deleteMutation.mutateAsync(id);
      setSelectedId(null);
    }
  };

  return (
    <FeatureLayout
      title="Ocorrências"
      tabs={tabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {activeTab === "listar" && (
        <div className="flex flex-col gap-6">
          {isLoadingList ? (
            <LoadingSpinner />
          ) : (
            <OccurrencesTable
              occurrences={occurrencesData?.occurrences}
              onSelectOccurrence={setSelectedId}
            />
          )}
        </div>
      )}

      {activeTab === "criar" && (
        <div className="rounded-2xl border border-text/20 bg-surface/10 p-8 text-text backdrop-blur-sm">
          {!canModerate ? (
            <p className="text-text/70">
              Você não tem permissão para criar ocorrências.
            </p>
          ) : (
            <OccurrenceForm
              onSubmit={handleCreateOccurrence}
              isLoading={createMutation.isPending}
              onCancel={() => setActiveTab("listar")}
            />
          )}
        </div>
      )}

      {/* Modal de Detalhe */}
      <Modal
        isOpen={selectedId !== null}
        onClose={() => setSelectedId(null)}
        title="Detalhes da Ocorrência"
      >
        {isLoadingDetail ? (
          <LoadingSpinner />
        ) : selectedOccurrence ? (
          <OccurrenceDetail
            occurrence={selectedOccurrence}
            onDelete={canModerate ? handleDeleteOccurrence : undefined}
          />
        ) : null}
      </Modal>
    </FeatureLayout>
  );
}
