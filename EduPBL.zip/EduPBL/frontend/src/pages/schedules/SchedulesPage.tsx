/**
 * SchedulesPage — /horarios
 *
 * Lógica de visualização por papel:
 *   - ADMIN / COORD / PORTEIRO  → SCHEDULES_VIEW_ALL  → seletor de turma + aba professor
 *   - PROFESSOR                 → SCHEDULES_VIEW_ALL  → grade própria (por userId) + aba turma
 *   - ALUNO                     → SCHEDULES_VIEW_OWN  → grade da própria turma (classroom_id)
 *   - RESPONSÁVEL               → SCHEDULES_VIEW_CHILD → igual aluno (classroom_id do filho via user)
 *
 * Tabs:
 *   "turma"     — grade de uma turma (selecionável se VIEW_ALL, fixo se OWN/CHILD)
 *   "professor" — grade de um professor (só quem tem VIEW_ALL)
 */

import { useState, useMemo } from "react";
import {
  FeatureLayout,
  type FeatureTab,
} from "@/components/layout/FeatureLayout";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import { usePermissions } from "@/features/auth/hooks/usePermissions";
import { useCurrentUser } from "@/features/auth/hooks/useAuth";
import { Permissions } from "@/features/auth/models/Permissions";
import {
  useClassrooms,
  useClassroomSchedule,
  useTeacherSchedule,
  usePeriods,
} from "@/features/schedules/hooks/useSchedules";
import type {
  ScheduleSlot,
  WeekdayEnum,
  Period,
} from "@/features/schedules/models/Schedule";
import type {
  Classroom,
  TeacherPublic,
} from "@/features/schedules/services/schedulesApi";
import { schedulesApi } from "@/features/schedules/services/schedulesApi";
import { useQuery } from "@tanstack/react-query";

// ─── Dias úteis exibidos na grade ─────────────────────────────────────────── //

const WEEKDAYS: { value: WeekdayEnum; short: string; long: string }[] = [
  { value: 2, short: "Seg", long: "Segunda" },
  { value: 3, short: "Ter", long: "Terça" },
  { value: 4, short: "Qua", long: "Quarta" },
  { value: 5, short: "Qui", long: "Quinta" },
  { value: 6, short: "Sex", long: "Sexta" },
];

// ─── Helpers ──────────────────────────────────────────────────────────────── //

function formatTime(hms: string): string {
  return hms.slice(0, 5); // "HH:MM:SS" → "HH:MM"
}

function periodLabel(p: Period): string {
  if (p.type === "class_period" && p.period_number != null) {
    return `${p.period_number}ª aula`;
  }
  const labels: Record<string, string> = {
    planning: "Planejamento",
    free: "Livre",
    snack_break: "Intervalo",
    lunch_break: "Almoço",
  };
  return labels[p.type] ?? p.type;
}

// ─── Grade ────────────────────────────────────────────────────────────────── //

interface ScheduleGridProps {
  slots: ScheduleSlot[];
  periods: Period[];
  /** Mapa opcional teacher_id → nome, para exibir no card */
  teacherNames?: Map<number, string>;
  /** Mapa opcional classroom_id → nome */
  classroomNames?: Map<number, string>;
  /** Se true, mostra nome da turma em vez do professor (usado na aba professor) */
  showClassroom?: boolean;
}

function ScheduleGrid({
  slots,
  periods,
  teacherNames,
  classroomNames,
  showClassroom = false,
}: ScheduleGridProps) {
  // Filtra apenas aulas (ignora períodos sem number para a grade principal)
  const classPeriods = periods.filter(
    (p) => p.type === "class_period" && p.period_number != null,
  );

  // Índice rápido: (weekday, period_number) → slot
  const slotIndex = useMemo(() => {
    const map = new Map<string, ScheduleSlot>();
    for (const s of slots) {
      if (s.period_number != null) {
        map.set(`${s.weekday}-${s.period_number}`, s);
      }
    }
    return map;
  }, [slots]);

  if (classPeriods.length === 0) {
    return (
      <p className="text-center text-text/50 py-12">
        Nenhum período cadastrado.
      </p>
    );
  }

  return (
    <div className="w-full overflow-x-auto">
      <table className="w-full min-w-[600px] border-collapse text-sm">
        <thead>
          <tr>
            {/* Coluna de período */}
            <th className="w-28 py-3 px-4 text-left text-text/50 font-medium border-b border-text/10">
              Período
            </th>
            {WEEKDAYS.map((d) => (
              <th
                key={d.value}
                className="py-3 px-2 text-center text-text/70 font-semibold border-b border-text/10"
              >
                <span className="hidden sm:inline">{d.long}</span>
                <span className="sm:hidden">{d.short}</span>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {classPeriods.map((period) => (
            <tr
              key={period.period_number}
              className="group hover:bg-text/5 transition-colors"
            >
              {/* Período */}
              <td className="py-3 px-4 border-b border-text/10 align-top">
                <p className="font-semibold text-text/80">
                  {periodLabel(period)}
                </p>
                <p className="text-xs text-text/40 mt-0.5">
                  {formatTime(period.start)} – {formatTime(period.end)}
                </p>
              </td>

              {/* Células por dia */}
              {WEEKDAYS.map((day) => {
                const slot = slotIndex.get(
                  `${day.value}-${period.period_number}`,
                );

                if (!slot) {
                  return (
                    <td
                      key={day.value}
                      className="py-3 px-2 border-b border-text/10 text-center"
                    >
                      <span className="text-text/20">—</span>
                    </td>
                  );
                }

                const subtitle = showClassroom
                  ? (classroomNames?.get(slot.classroom_id) ??
                    `Turma ${slot.classroom_id}`)
                  : slot.teacher_id
                    ? (teacherNames?.get(slot.teacher_id) ?? "Professor")
                    : null;

                return (
                  <td
                    key={day.value}
                    className="py-2 px-2 border-b border-text/10"
                  >
                    <div className="rounded-xl bg-primary/10 border border-primary/20 px-3 py-2 text-center min-h-[54px] flex flex-col justify-center gap-0.5">
                      <p className="text-xs font-semibold text-primary leading-tight line-clamp-2">
                        {slot.title}
                      </p>
                      {subtitle && (
                        <p className="text-[10px] text-text/50 leading-tight">
                          {subtitle}
                        </p>
                      )}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Aba: Turma ───────────────────────────────────────────────────────────── //

interface ClassroomTabProps {
  canViewAll: boolean;
  /** classroom_id fixo (aluno/responsável) */
  fixedClassroomId: number | null;
  classrooms: Classroom[];
  periods: Period[];
}

function ClassroomTab({
  canViewAll,
  fixedClassroomId,
  classrooms,
  periods,
}: ClassroomTabProps) {
  const [selectedId, setSelectedId] = useState<number | null>(
    fixedClassroomId ?? classrooms[0]?.id ?? null,
  );

  const { data: scheduleData, isLoading } = useClassroomSchedule(selectedId);

  // Mapa teacher_id → nome para esta aba (busca todos os professores)
  const { data: teachers } = useQuery({
    queryKey: ["schedules", "all-teachers"],
    queryFn: schedulesApi.getAllTeachers,
    staleTime: 5 * 60 * 1000,
    enabled: canViewAll,
  });

  const teacherNames = useMemo(() => {
    const map = new Map<number, string>();
    for (const t of teachers ?? []) {
      map.set(t.id, `${t.first_name} ${t.last_name}`);
    }
    return map;
  }, [teachers]);

  const activeClassroom = classrooms.find((c) => c.id === selectedId);

  return (
    <div className="flex flex-col gap-6">
      {/* Seletor de turma — só para VIEW_ALL */}
      {canViewAll && classrooms.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {classrooms.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setSelectedId(c.id)}
              className={[
                "rounded-full px-4 py-1.5 text-sm font-medium transition",
                selectedId === c.id
                  ? "bg-primary text-white shadow-sm"
                  : "bg-surface/60 text-text/70 hover:bg-surface/90 border border-text/10",
              ].join(" ")}
            >
              {c.name}
            </button>
          ))}
        </div>
      )}

      {/* Título quando fixo */}
      {!canViewAll && activeClassroom && (
        <p className="text-text/60 text-sm">
          Exibindo horários da turma{" "}
          <span className="font-semibold text-text">
            {activeClassroom.name}
          </span>
        </p>
      )}

      {selectedId == null ? (
        <EmptyState message="Selecione uma turma para ver o horário." />
      ) : isLoading ? (
        <LoadingSpinner />
      ) : !scheduleData?.slots?.length ? (
        <EmptyState message="Nenhum horário cadastrado para esta turma." />
      ) : (
        <div className="rounded-2xl border border-text/10 bg-surface/10 backdrop-blur-sm overflow-hidden">
          <ScheduleGrid
            slots={scheduleData.slots}
            periods={periods}
            teacherNames={teacherNames}
          />
        </div>
      )}
    </div>
  );
}

// ─── Aba: Professor ───────────────────────────────────────────────────────── //

interface TeacherTabProps {
  teachers: TeacherPublic[];
  periods: Period[];
  classrooms: Classroom[];
}

function TeacherTab({ teachers, periods, classrooms }: TeacherTabProps) {
  const [selectedId, setSelectedId] = useState<number | null>(
    teachers[0]?.id ?? null,
  );

  const { data: scheduleData, isLoading } = useTeacherSchedule(selectedId);

  const classroomNames = useMemo(() => {
    const map = new Map<number, string>();
    for (const c of classrooms) map.set(c.id, c.name);
    return map;
  }, [classrooms]);

  const activeTeacher = teachers.find((t) => t.id === selectedId);

  return (
    <div className="flex flex-col gap-6">
      {/* Seletor de professor */}
      {teachers.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {teachers.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSelectedId(t.id)}
              className={[
                "rounded-full px-4 py-1.5 text-sm font-medium transition",
                selectedId === t.id
                  ? "bg-primary text-white shadow-sm"
                  : "bg-surface/60 text-text/70 hover:bg-surface/90 border border-text/10",
              ].join(" ")}
            >
              {t.first_name} {t.last_name}
            </button>
          ))}
        </div>
      )}

      {activeTeacher && (
        <p className="text-text/60 text-sm">
          Grade de{" "}
          <span className="font-semibold text-text">
            {activeTeacher.first_name} {activeTeacher.last_name}
          </span>
        </p>
      )}

      {selectedId == null ? (
        <EmptyState message="Selecione um professor para ver o horário." />
      ) : isLoading ? (
        <LoadingSpinner />
      ) : !scheduleData?.slots?.length ? (
        <EmptyState message="Nenhum horário cadastrado para este professor." />
      ) : (
        <div className="rounded-2xl border border-text/10 bg-surface/10 backdrop-blur-sm overflow-hidden">
          <ScheduleGrid
            slots={scheduleData.slots}
            periods={periods}
            classroomNames={classroomNames}
            showClassroom
          />
        </div>
      )}
    </div>
  );
}

// ─── Empty state ──────────────────────────────────────────────────────────── //

function EmptyState({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-text/10 bg-surface/10 backdrop-blur-sm px-8 py-16 text-center">
      <p className="text-text/40">{message}</p>
    </div>
  );
}

// ─── Página principal ─────────────────────────────────────────────────────── //

export default function SchedulesPage() {
  const { user } = useCurrentUser();
  const { can, canAny } = usePermissions();

  const canViewAll = can(Permissions.SCHEDULES_VIEW_ALL);
  const canViewOwn = can(Permissions.SCHEDULES_VIEW_OWN);
  const canViewChild = can(Permissions.SCHEDULES_VIEW_CHILD);

  // Aluno/Responsável usam classroom_id fixo do próprio perfil
  const fixedClassroomId =
    !canViewAll && (canViewOwn || canViewChild)
      ? (user?.classroom_id ?? null)
      : null;

  const { data: periodsData, isLoading: isLoadingPeriods } = usePeriods();
  const { data: classrooms = [], isLoading: isLoadingClassrooms } =
    useClassrooms();

  // Professores — só necessário para VIEW_ALL
  const { data: teachers = [], isLoading: isLoadingTeachers } = useQuery({
    queryKey: ["schedules", "all-teachers"],
    queryFn: schedulesApi.getAllTeachers,
    staleTime: 5 * 60 * 1000,
    enabled: canViewAll,
  });

  // Tabs disponíveis
  const tabs = useMemo<FeatureTab[]>(() => {
    const t: FeatureTab[] = [{ id: "turma", label: "Por turma" }];
    if (canViewAll) t.push({ id: "professor", label: "Por professor" });
    return t;
  }, [canViewAll]);

  const [activeTab, setActiveTab] = useState<string>("turma");

  const isLoading =
    isLoadingPeriods ||
    isLoadingClassrooms ||
    (canViewAll && isLoadingTeachers);

  const periods = periodsData?.periods ?? [];

  return (
    <FeatureLayout
      title="Horários"
      tabs={tabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {isLoading ? (
        <LoadingSpinner />
      ) : !canAny(
          Permissions.SCHEDULES_VIEW_ALL,
          Permissions.SCHEDULES_VIEW_OWN,
          Permissions.SCHEDULES_VIEW_CHILD,
        ) ? (
        <EmptyState message="Você não tem permissão para ver horários." />
      ) : (
        <>
          {activeTab === "turma" && (
            <ClassroomTab
              canViewAll={canViewAll}
              fixedClassroomId={fixedClassroomId}
              classrooms={classrooms}
              periods={periods}
            />
          )}

          {activeTab === "professor" && canViewAll && (
            <TeacherTab
              teachers={teachers}
              periods={periods}
              classrooms={classrooms}
            />
          )}
        </>
      )}
    </FeatureLayout>
  );
}
