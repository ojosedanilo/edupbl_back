import { useState, useRef } from "react";
import CircularProgress from "@mui/material/CircularProgress";
import PhotoCameraIcon from "@mui/icons-material/PhotoCamera";
import { FeatureLayout } from "@/components/layout/FeatureLayout";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/TextField";
import { useCurrentUser } from "@/features/auth/hooks/useAuth";
import { api } from "@/shared/services/api";
import { queryClient } from "@/features/auth/hooks/AuthContext";
import { ME_QUERY_KEY } from "@/features/auth/hooks/useAuth";
import { useAvatarUrl } from "@/features/users/hooks/useAvatarUrl";
import { usePermissions } from "@/features/auth/hooks/usePermissions";
import { Permissions } from "@/features/auth/models/Permissions";
import { extractApiError } from "@/shared/utils/apiMessages";
import {
  profileFields,
  groupMeta,
  type FieldGroup,
  type ProfileFieldConfig,
} from "@/features/users/config/profileFields";
import type { UserMe } from "@/features/auth/models/UserMe";

type EditableFields = Pick<
  UserMe,
  "first_name" | "last_name" | "username" | "email" | "phone"
>;

// ── Avatar ───────────────────────────────────────────────────────────────── //

function AvatarSection({ user }: { user: UserMe }) {
  const [uploading, setUploading] = useState(false);
  const [avatarKey, setAvatarKey] = useState(0);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const avatarUrl = useAvatarUrl(user.id, avatarKey, !!user.avatar_url);

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setUploadError(null);
    try {
      const form = new FormData();
      form.append("file", file);
      await api.patch("/users/me/avatar", form, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      queryClient.setQueryData<UserMe>(ME_QUERY_KEY, (old) =>
        old ? { ...old, avatar_url: `avatars/${user.id}.webp` } : old,
      );
      setAvatarKey((k) => k + 1);
    } catch (err: unknown) {
      const msg = extractApiError(err, "Erro ao enviar foto.");
      setUploadError(msg);
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  }

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative">
        <div className="w-40 aspect-square overflow-hidden rounded-full border-4 border-primary bg-surface/30">
          {avatarUrl ? (
            <img
              src={avatarUrl}
              alt="Foto de perfil"
              className="size-full object-cover"
            />
          ) : (
            <div className="flex size-full items-center justify-center text-4xl font-bold text-primary">
              {user.first_name[0].toUpperCase()}
            </div>
          )}
        </div>
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          disabled={uploading}
          className="absolute bottom-0 right-0 flex size-12 items-center justify-center rounded-full bg-primary text-white shadow-md transition hover:opacity-90 disabled:opacity-50"
          aria-label="Trocar foto"
          title="Trocar foto"
        >
          {uploading ? <CircularProgress size={20} /> : <PhotoCameraIcon />}
        </button>
      </div>
      <input
        ref={fileInputRef}
        type="file"
        accept="image/jpeg,image/png,image/webp"
        className="hidden"
        onChange={handleFileChange}
      />
      {uploadError && <p className="text-sm text-danger">{uploadError}</p>}
      <div className="text-center">
        <p className="text-xl font-bold text-text">
          {user.first_name} {user.last_name}
        </p>
        <p className="text-sm text-text/60">
          {profileFields.find((f) => f.key === "role")?.format?.(user.role) ??
            user.role}
        </p>
      </div>
    </div>
  );
}

// ── Campo somente-leitura ─────────────────────────────────────────────────── //

function StaticField({
  config,
  value,
}: {
  config: ProfileFieldConfig;
  value: UserMe[keyof UserMe];
}) {
  const display = config.format
    ? config.format(value)
    : value != null
      ? String(value)
      : "—";
  return (
    <div className="flex flex-col gap-1">
      <span className="text-sm font-medium text-text/60">{config.label}</span>
      <span className="text-base text-text">{display || "—"}</span>
    </div>
  );
}

// ── Seção de grupo de campos ──────────────────────────────────────────────── //

function FieldGroupSection({
  group,
  fields,
  user,
  draft,
  onChange,
  fieldErrors,
}: {
  group: FieldGroup;
  fields: ProfileFieldConfig[];
  user: UserMe;
  draft: Partial<EditableFields>;
  onChange: (key: keyof EditableFields, value: string) => void;
  fieldErrors?: Partial<Record<keyof EditableFields, string>>;
}) {
  const meta = groupMeta[group];
  const editableFields = fields.filter((f) => f.editable);
  const staticFields = fields.filter((f) => !f.editable);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h2 className="text-lg font-semibold text-text">{meta.title}</h2>
        <p className="text-sm text-text/50">{meta.description}</p>
      </div>

      {editableFields.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {editableFields.map((field) => {
            const key = field.key as keyof EditableFields;
            const currentVal = draft[key] ?? (user[field.key] as string) ?? "";
            return (
              <div key={field.key} className="flex flex-col gap-1">
                <TextField
                  label={field.label}
                  name={field.key}
                  type={field.type}
                  value={currentVal}
                  onChange={(e) => onChange(key, e.target.value)}
                  error={fieldErrors?.[key]}
                />
                {field.hint && (
                  <p className="px-4 text-xs text-text/40">{field.hint}</p>
                )}
              </div>
            );
          })}
        </div>
      )}

      {staticFields.length > 0 && (
        <div className="grid gap-4 sm:grid-cols-2">
          {staticFields.map((field) => (
            <StaticField
              key={field.key}
              config={field}
              value={user[field.key]}
            />
          ))}
        </div>
      )}
    </div>
  );
}

// ── Formulário principal de perfil ────────────────────────────────────────── //

function ProfileDataForm({ user }: { user: UserMe }) {
  const { can, isLoading: permissionsLoading } = usePermissions();
  const [draft, setDraft] = useState<Partial<EditableFields>>({});
  const [fieldErrors, setFieldErrors] = useState<
    Partial<Record<keyof EditableFields, string>>
  >({});
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Campos restritos por padrão, liberados apenas para quem tem users:update
  // (admins e coordenadores). O campo "phone" é editável por todos e não entra aqui.
  const PRIVILEGED_FIELDS: Array<keyof EditableFields> = [
    "first_name",
    "last_name",
    "username",
    "email",
  ];

  const canEditAll = can(Permissions.USER_EDIT);

  // Aplica override de editable para campos privilegiados:
  // - Campos em PRIVILEGED_FIELDS ficam editáveis apenas para admins/coords
  // - Campos fora de PRIVILEGED_FIELDS (ex: phone) mantêm o editable do profileFields.ts
  const effectiveFields: ProfileFieldConfig[] = profileFields.map((f) => {
    const key = f.key as keyof EditableFields;
    if (PRIVILEGED_FIELDS.includes(key)) {
      return { ...f, editable: canEditAll };
    }
    return f;
  });

  const editableKeys = effectiveFields
    .filter((f) => f.editable)
    .map((f) => f.key as keyof EditableFields);

  const hasFieldErrors = Object.values(fieldErrors).some(Boolean);

  const isDirty = editableKeys.some(
    (key) =>
      draft[key] !== undefined && draft[key] !== ((user[key] as string) ?? ""),
  );

  function handleChange(key: keyof EditableFields, value: string) {
    setDraft((prev) => ({ ...prev, [key]: value }));
    setSuccess(false);
    setError(null);

    // Validação em tempo real por campo
    let fieldErr: string | null = null;
    if (key === "email") fieldErr = validateEmail(value);
    if (key === "phone") fieldErr = validatePhone(value);
    setFieldErrors((prev) => ({ ...prev, [key]: fieldErr ?? undefined }));
  }

  // ── Validações de campo ────────────────────────────────────────────────── //
  // email: pré-validado para quando a edição for reativada em profileFields.ts
  function validateEmail(email: string): string | null {
    if (!email) return null;
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email) ? null : "E-mail inválido.";
  }

  // phone: validação ativa (campo editável)
  function validatePhone(phone: string): string | null {
    if (!phone) return null;
    // Aceita formatos: +5585999990000, (85) 99999-0000, 85999990000, etc.
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 10 || digits.length > 13) {
      return "Telefone inválido. Ex: +5585999990000";
    }
    return null;
  }

  function validateDraft(): string | null {
    if (draft.email !== undefined) {
      const emailErr = validateEmail(draft.email ?? "");
      if (emailErr) return emailErr;
    }
    if (draft.phone !== undefined) {
      const phoneErr = validatePhone(draft.phone ?? "");
      if (phoneErr) return phoneErr;
    }
    return null;
  }

  async function handleSave() {
    const validationError = validateDraft();
    if (validationError) {
      setError(validationError);
      return;
    }

    setSaving(true);
    setSuccess(false);
    setError(null);

    const payload: Partial<EditableFields> = {};
    for (const key of editableKeys) {
      if (draft[key] !== undefined) payload[key] = draft[key];
    }

    try {
      const { data } = await api.put<UserMe>(`/users/${user.id}`, payload);
      queryClient.setQueryData<UserMe>(ME_QUERY_KEY, (old) =>
        old ? { ...old, ...data } : old,
      );
      setDraft({});
      setSuccess(true);
    } catch (err: unknown) {
      const msg = extractApiError(err, "Erro ao salvar dados.");
      setError(msg);
    } finally {
      setSaving(false);
    }
  }

  const groups: FieldGroup[] = ["personal", "account", "system"];

  // Aguarda as permissões carregarem antes de renderizar os campos
  // para evitar que campos restritos apareçam editáveis momentaneamente.
  if (permissionsLoading) return null;

  return (
    <div className="flex flex-col gap-8">
      {groups.map((group, i) => (
        <div key={group}>
          <FieldGroupSection
            group={group}
            fields={effectiveFields.filter((f) => f.group === group)}
            user={user}
            draft={draft}
            onChange={handleChange}
            fieldErrors={fieldErrors}
          />
          {i < groups.length - 1 && <hr className="mt-8 border-text/95" />}
        </div>
      ))}

      {error && <p className="text-sm text-danger">{error}</p>}
      {success && (
        <p className="text-sm text-green-400">Dados atualizados com sucesso!</p>
      )}

      <div>
        <Button
          onClick={handleSave}
          disabled={!isDirty || saving || hasFieldErrors}
          variant="primary"
        >
          {saving ? "Salvando…" : "Salvar alterações"}
        </Button>
      </div>
    </div>
  );
}

// ── Alterar senha ─────────────────────────────────────────────────────────── //

function ChangePasswordForm() {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function reset() {
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  }

  async function handleSave() {
    if (newPassword !== confirmPassword) {
      setError("As senhas não coincidem.");
      return;
    }
    setSaving(true);
    setSuccess(false);
    setError(null);
    try {
      await api.patch("/users/me/password", {
        current_password: currentPassword,
        new_password: newPassword,
      });
      setSuccess(true);
      reset();
    } catch (err: unknown) {
      const msg = extractApiError(err, "Erro ao alterar senha.");
      setError(msg);
    } finally {
      setSaving(false);
    }
  }

  const isFilled = currentPassword && newPassword && confirmPassword;

  return (
    <section className="flex flex-col gap-4">
      <div>
        <h2 className="text-lg font-semibold text-text">Alterar senha</h2>
        <p className="text-sm text-text/50">
          Requer confirmação da senha atual.
        </p>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <TextField
            label="Senha atual"
            name="current_password"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
          />
        </div>
        <TextField
          label="Nova senha"
          name="new_password"
          type="password"
          value={newPassword}
          onChange={(e) => setNewPassword(e.target.value)}
        />
        <TextField
          label="Confirmar nova senha"
          name="confirm_password"
          type="password"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          error={
            confirmPassword && newPassword !== confirmPassword
              ? "As senhas não coincidem"
              : undefined
          }
        />
      </div>
      {error && <p className="text-sm text-danger">{error}</p>}
      {success && (
        <p className="text-sm text-green-400">Senha alterada com sucesso!</p>
      )}
      <div>
        <Button
          onClick={handleSave}
          disabled={!isFilled || saving}
          variant="primary"
        >
          {saving ? "Salvando…" : "Alterar senha"}
        </Button>
      </div>
    </section>
  );
}

// ── Página ────────────────────────────────────────────────────────────────── //

export default function ProfilePage() {
  const { user } = useCurrentUser();
  if (!user) return null;

  return (
    <FeatureLayout title="Perfil">
      <div className="mx-auto flex max-w-2xl flex-col gap-10">
        <div className="rounded-2xl bg-bg p-8 backdrop-blur-sm">
          <AvatarSection user={user} />
        </div>
        <div className="rounded-2xl bg-bg p-8 backdrop-blur-sm">
          <ProfileDataForm user={user} />
        </div>
        <div className="rounded-2xl bg-bg p-8 backdrop-blur-sm">
          <ChangePasswordForm />
        </div>
      </div>
    </FeatureLayout>
  );
}
