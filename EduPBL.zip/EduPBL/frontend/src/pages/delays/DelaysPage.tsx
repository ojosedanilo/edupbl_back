import { useState } from "react";
import {
  FeatureLayout,
  type FeatureTab,
} from "@/components/layout/FeatureLayout";
import { DelaysTable } from "@/components/dashboard/DelaysTable";
import { DelayForm } from "@/components/dashboard/DelayForm";
import { Modal } from "@/components/ui/Modal";
import { DelayDetail } from "@/components/dashboard/DelayDetail";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";
import {
  useDelays,
  useDelaysPending,
  useCreateDelay,
  useApproveDelay,
  useRejectDelay,
  useDelayById,
} from "@/features/delays/hooks/useDelays";
import { usePermissions } from "@/features/auth/hooks/usePermissions";

const tabs: FeatureTab[] = [
  { id: "listar", label: "Listar" },
  { id: "registrar", label: "Registrar Atraso" },
  { id: "pendentes", label: "Pendentes" },
];

export default function DelaysPage() {
  const [activeTab, setActiveTab] = useState<string>("listar");
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [rejectReason, setRejectReason] = useState("");
  const [showRejectForm, setShowRejectForm] = useState(false);

  const { data: delaysData, isLoading: isLoadingList } = useDelays();
  const { data: pendingData, isLoading: isLoadingPending } = useDelaysPending();
  const { data: selectedDelay, isLoading: isLoadingDetail } =
    useDelayById(selectedId!);
  const createMutation = useCreateDelay();
  const approveMutation = useApproveDelay(selectedId!);
  const rejectMutation = useRejectDelay(selectedId!);
  const { canReviewDelays, canRegisterDelays } = usePermissions();

  const handleCreateDelay = async (formData: {
    student_id: number;
    arrival_time: string;
    reason?: string;
  }) => {
    await createMutation.mutateAsync(formData);
    setActiveTab("listar");
  };

  const handleApproveDelay = async () => {
    if (selectedId) {
      await approveMutation.mutateAsync();
      setSelectedId(null);
    }
  };

  const handleRejectDelay = async () => {
    if (selectedId && rejectReason) {
      await rejectMutation.mutateAsync({ rejection_reason: rejectReason });
      setRejectReason("");
      setShowRejectForm(false);
      setSelectedId(null);
    }
  };

  return (
    <FeatureLayout
      title="Atrasos"
      tabs={tabs}
      activeTab={activeTab}
      onTabChange={setActiveTab}
    >
      {activeTab === "listar" && (
        <div className="flex flex-col gap-6">
          {isLoadingList ? (
            <LoadingSpinner />
          ) : (
            <DelaysTable
              delays={delaysData?.delays}
              onSelectDelay={setSelectedId}
            />
          )}
        </div>
      )}

      {activeTab === "registrar" && (
        <div className="rounded-2xl border border-text/20 bg-surface/10 p-8 text-text backdrop-blur-sm">
          {!canRegisterDelays ? (
            <p className="text-text/70">
              Você não tem permissão para registrar atrasos.
            </p>
          ) : (
            <DelayForm
              onSubmit={handleCreateDelay}
              isLoading={createMutation.isPending}
              onCancel={() => setActiveTab("listar")}
            />
          )}
        </div>
      )}

      {activeTab === "pendentes" && (
        <div className="flex flex-col gap-6">
          {isLoadingPending ? (
            <LoadingSpinner />
          ) : !canReviewDelays ? (
            <p className="text-text/70">
              Você não tem permissão para revisar atrasos.
            </p>
          ) : (
            <DelaysTable
              delays={pendingData?.delays}
              onSelectDelay={setSelectedId}
              showActions={true}
              onApprove={handleApproveDelay}
              onReject={() => setShowRejectForm(true)}
            />
          )}
        </div>
      )}

      {/* Modal de Detalhe */}
      <Modal
        isOpen={selectedId !== null}
        onClose={() => {
          setSelectedId(null);
          setShowRejectForm(false);
          setRejectReason("");
        }}
        title="Detalhes do Atraso"
      >
        {isLoadingDetail ? (
          <LoadingSpinner />
        ) : selectedDelay ? (
          !showRejectForm ? (
            <DelayDetail
              delay={selectedDelay}
              onApprove={
                canReviewDelays && selectedDelay.status === "PENDING"
                  ? handleApproveDelay
                  : undefined
              }
              onReject={
                canReviewDelays && selectedDelay.status === "PENDING"
                  ? () => setShowRejectForm(true)
                  : undefined
              }
            />
          ) : (
            <div className="flex flex-col gap-4">
              <p className="text-sm text-text/70">
                Qual o motivo da rejeição?
              </p>
              <textarea
                placeholder="Digite o motivo da rejeição..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="w-full rounded-2xl border-4 border-primary bg-transparent px-5 py-3 text-text shadow-md placeholder:text-text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/40"
                rows={4}
              />
              <div className="flex gap-4">
                <button
                  onClick={handleRejectDelay}
                  disabled={!rejectReason || rejectMutation.isPending}
                  className="flex-1 px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition font-semibold disabled:opacity-50"
                >
                  {rejectMutation.isPending ? "Rejeitando..." : "Rejeitar"}
                </button>
                <button
                  onClick={() => {
                    setShowRejectForm(false);
                    setRejectReason("");
                  }}
                  className="flex-1 px-4 py-2 rounded-lg bg-text/10 text-text hover:bg-text/20 transition font-semibold"
                >
                  Cancelar
                </button>
              </div>
            </div>
          )
        ) : null}
      </Modal>
    </FeatureLayout>
  );
}
