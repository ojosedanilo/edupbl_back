import { Routes, Route } from "react-router-dom";
import ProtectedRoutes from "@/routes/ProtectedRoutes";
import PublicOnlyRoute from "@/routes/PublicOnlyRoute";
import SmartRedirect from "@/routes/SmartRedirect";

import NotFound from "@/shared/pages/NotFound";

import LandingPage from "@/pages/landing/LandingPage";

import HomePage from "@/pages/dashboard/HomePage";
import ProfilePage from "@/pages/dashboard/ProfilePage";

import LoginPage from "@/pages/auth/LoginPage";
// import SignupPage from "@/pages/auth/SignupPage";

import DelaysPage from "@/pages/delays/DelaysPage";
import SchedulesPage from "@/pages/schedules/SchedulesPage";
import UsersPage from "@/pages/users/UsersPage";

import OccurrencesPage from "@/pages/occurrences/OccurrencesPage";

import { Permissions } from "@/features/auth/models/Permissions";
import PermissionRoute from "@/routes/PermissionRoute";

export function AppRoutes() {
  return (
    <Routes>
      {/* Landing — redireciona logados para /inicio, mas permite voltar */}
      <Route element={<SmartRedirect />}>
        <Route path="/" element={<LandingPage />} />
      </Route>

      {/* Rotas de auth — redireciona para /inicio se já estiver logado */}
      <Route element={<PublicOnlyRoute />}>
        <Route path="/entrar" element={<LoginPage />} />
        {/*
        <Route path="/cadastrar" element={<SignupPage />} />
        */}
      </Route>

      {/* Rotas que exigem login */}
      <Route element={<ProtectedRoutes />}>
        <Route path="/inicio" element={<HomePage />} />
        <Route path="/perfil" element={<ProfilePage />} />

        {/* Ocorrências */}
        <Route
          element={
            <PermissionRoute
              anyOf={[
                Permissions.OCCURRENCES_CREATE,
                Permissions.OCCURRENCES_VIEW_ALL,
                Permissions.OCCURRENCES_VIEW_OWN,
                Permissions.OCCURRENCES_VIEW_CHILD,
                Permissions.OCCURRENCES_VIEW_OWN_CLASSROOM,
              ]}
            />
          }
        >
          <Route path="/ocorrencias" element={<OccurrencesPage />} />
        </Route>

        {/* Atrasos */}
        <Route
          element={
            <PermissionRoute
              anyOf={[
                Permissions.DELAYS_CREATE,
                Permissions.DELAYS_REVIEW,
                Permissions.DELAYS_VIEW_ALL,
                Permissions.DELAYS_VIEW_OWN,
                Permissions.DELAYS_VIEW_CHILD,
                Permissions.DELAYS_VIEW_OWN_CLASSROOM,
              ]}
            />
          }
        >
          <Route path="/atrasos" element={<DelaysPage />} />
        </Route>

        {/* Horários */}
        <Route
          element={
            <PermissionRoute
              anyOf={[
                Permissions.SCHEDULES_VIEW_ALL,
                Permissions.SCHEDULES_VIEW_OWN,
                Permissions.SCHEDULES_VIEW_CHILD,
                Permissions.SCHEDULES_MANAGE,
              ]}
            />
          }
        >
          <Route path="/horarios" element={<SchedulesPage />} />
        </Route>

        {/* Usuários */}
        <Route
          element={
            <PermissionRoute
              anyOf={[
                Permissions.USER_VIEW_ALL,
                Permissions.USER_VIEW_OWN,
                Permissions.USER_VIEW_CHILD,
              ]}
            />
          }
        >
          <Route path="/usuarios" element={<UsersPage />} />
        </Route>
      </Route>

      {/* Página não encontrada */}
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
}
