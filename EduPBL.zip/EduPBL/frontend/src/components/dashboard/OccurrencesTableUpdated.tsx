import { cn } from "@/utils/cn";
import type { OccurrencePublic } from "@/features/occurrences/services/occurrencesApi";
import { formatDate } from "../../utils/date";

type OccurrencesTableProps = {
  occurrences?: OccurrencePublic[];
  isLoading?: boolean;
  onSelectOccurrence?: (id: number) => void;
  className?: string;
};

export function OccurrencesTable({
  occurrences,
  isLoading,
  onSelectOccurrence,
  className,
}: OccurrencesTableProps) {
  const displayRows = occurrences || [];
  const hasItems = displayRows.length > 0;

  return (
    <div
      className={cn(
        "overflow-hidden rounded-[20px] border border-text/40 bg-surface/10 backdrop-blur-sm",
        className
      )}
    >
      {/* Header */}
      <div
        className={cn(
          "grid grid-cols-[1.2fr_1.4fr_1fr_1.2fr_0.8fr] gap-0 border-b border-text/30",
          "bg-gradient-to-r from-transparent via-text/5 to-transparent px-4 py-3 text-sm font-medium text-text md:text-base"
        )}
      >
        <div className="px-2">Aluno</div>
        <div className="px-2">Problema</div>
        <div className="px-2">Data</div>
        <div className="px-2">Professor</div>
        <div className="px-2">Ações</div>
      </div>

      {/* Rows */}
      <div className="divide-y divide-text/20">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className="grid grid-cols-[1.2fr_1.4fr_1fr_1.2fr_0.8fr] px-4 py-4 text-sm md:text-base"
            >
              {Array.from({ length: 5 }).map((_, j) => (
                <div
                  key={j}
                  className="px-2 h-4 bg-text/10 rounded animate-pulse"
                />
              ))}
            </div>
          ))
        ) : !hasItems ? (
          <div className="col-span-5 px-4 py-8 text-center text-text/60">
            Nenhuma ocorrência registrada
          </div>
        ) : (
          displayRows.map((row) => (
            <div
              key={row.id}
              className="grid grid-cols-[1.2fr_1.4fr_1fr_1.2fr_0.8fr] px-4 py-4 text-sm text-text/95 md:text-base hover:bg-surface/10 transition"
            >
              <div className="truncate px-2">Aluno {row.student_id}</div>
              <div className="truncate px-2 text-text/80">{row.title}</div>
              <div className="px-2 text-text/70">
                {formatDate(new Date(row.created_at))}
              </div>
              <div className="px-2 text-text/70">
                Prof {row.created_by_id || "—"}
              </div>
              <div className="px-2">
                <button
                  onClick={() => onSelectOccurrence?.(row.id)}
                  className="px-2 py-1 rounded text-sm bg-primary/20 text-primary hover:bg-primary/30 transition"
                >
                  Ver
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
