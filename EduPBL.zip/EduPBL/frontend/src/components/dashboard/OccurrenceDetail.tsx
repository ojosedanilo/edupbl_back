import { formatDate, formatTime } from "../../utils/date";
import type { OccurrencePublic } from "@/features/occurrences/services/occurrencesApi";

type OccurrenceDetailProps = {
  occurrence: OccurrencePublic;
  onEdit?: (id: number) => void;
  onDelete?: (id: number) => void;
};

export function OccurrenceDetail({
  occurrence,
  onEdit,
  onDelete,
}: OccurrenceDetailProps) {
  return (
    <div className="flex flex-col gap-6">
      {/* Info */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-text/60">Aluno ID</p>
          <p className="text-lg font-semibold text-text">{occurrence.student_id}</p>
        </div>
        <div>
          <p className="text-sm text-text/60">Registrado por</p>
          <p className="text-lg font-semibold text-text">
            {occurrence.created_by_id ? `Prof ${occurrence.created_by_id}` : "—"}
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Data</p>
          <p className="text-lg font-semibold text-text">
            {formatDate(new Date(occurrence.created_at))}
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Hora</p>
          <p className="text-lg font-semibold text-text">
            {formatTime(occurrence.created_at)}
          </p>
        </div>
      </div>

      {/* Title */}
      <div>
        <p className="text-sm text-text/60">Título</p>
        <p className="text-base font-semibold text-text">{occurrence.title}</p>
      </div>

      {/* Description */}
      <div>
        <p className="text-sm text-text/60">Descrição</p>
        <p className="text-base text-text/90 whitespace-pre-wrap">
          {occurrence.description}
        </p>
      </div>

      {/* Actions */}
      {(onEdit || onDelete) && (
        <div className="flex gap-4 pt-4">
          {onEdit && (
            <button
              onClick={() => onEdit(occurrence.id)}
              className="px-4 py-2 rounded-lg bg-primary/20 text-primary hover:bg-primary/30 transition font-semibold"
            >
              Editar
            </button>
          )}
          {onDelete && (
            <button
              onClick={() => onDelete(occurrence.id)}
              className="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition font-semibold"
            >
              Deletar
            </button>
          )}
        </div>
      )}
    </div>
  );
}
