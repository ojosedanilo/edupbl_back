import { useState } from "react";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/TextField";
import type { DelayCreate } from "@/features/delays/services/delaysApi";

type DelayFormProps = {
  onSubmit: (data: DelayCreate) => Promise<void>;
  isLoading?: boolean;
  onCancel?: () => void;
};

export function DelayForm({
  onSubmit,
  isLoading,
  onCancel,
}: DelayFormProps) {
  const [studentId, setStudentId] = useState("");
  const [arrivalTime, setArrivalTime] = useState("");
  const [reason, setReason] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!studentId || !arrivalTime) {
      setError("Preencha os campos obrigatórios: ID do aluno e horário");
      return;
    }

    try {
      await onSubmit({
        student_id: parseInt(studentId, 10),
        arrival_time: arrivalTime,
        reason: reason || undefined,
      });

      // Reset form on success
      setStudentId("");
      setArrivalTime("");
      setReason("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao registrar atraso");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 max-w-2xl">
      {error && (
        <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-4 text-red-400">
          {error}
        </div>
      )}

      <div className="flex flex-col gap-4">
        <TextField
          label="ID do Aluno"
          type="number"
          placeholder="Ex: 123"
          value={studentId}
          onChange={(e) => setStudentId(e.target.value)}
          required
        />

        <TextField
          label="Horário de Chegada"
          type="time"
          value={arrivalTime}
          onChange={(e) => setArrivalTime(e.target.value)}
          required
        />

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium text-text-muted">
            Motivo (Opcional)
          </label>
          <textarea
            placeholder="Ex: Problemas com o transporte"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            className="w-full rounded-2xl border-4 border-primary bg-transparent px-5 py-3 text-text shadow-md placeholder:text-text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/40"
            rows={3}
          />
        </div>
      </div>

      <div className="flex gap-4">
        <Button type="submit" variant="primary" disabled={isLoading}>
          {isLoading ? "Registrando..." : "Registrar Atraso"}
        </Button>
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancelar
          </Button>
        )}
      </div>
    </form>
  );
}
