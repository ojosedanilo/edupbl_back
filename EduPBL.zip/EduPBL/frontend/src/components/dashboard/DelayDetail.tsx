import { formatDate, formatTime } from "../../utils/date";
import type { DelayPublic } from "@/features/delays/services/delaysApi";

function getStatusLabel(status: string) {
  switch (status) {
    case "APPROVED":
      return "Aprovado";
    case "REJECTED":
      return "Rejeitado";
    case "PENDING":
      return "Pendente";
    default:
      return status;
  }
}

type DelayDetailProps = {
  delay: DelayPublic;
  onApprove?: (id: number) => void;
  onReject?: (id: number) => void;
};

export function DelayDetail({
  delay,
  onApprove,
  onReject,
}: DelayDetailProps) {
  return (
    <div className="flex flex-col gap-6">
      {/* Status Badge */}
      <div className="flex items-center gap-2">
        <p className="text-sm text-text/60">Status:</p>
        <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold
          ${delay.status === "APPROVED" ? "bg-green-500/20 text-green-400" : ""}
          ${delay.status === "REJECTED" ? "bg-red-500/20 text-red-400" : ""}
          ${delay.status === "PENDING" ? "bg-yellow-500/20 text-yellow-400" : ""}
        `}>
          {getStatusLabel(delay.status)}
        </span>
      </div>

      {/* Main Info */}
      <div className="grid grid-cols-2 gap-4">
        <div>
          <p className="text-sm text-text/60">Aluno ID</p>
          <p className="text-lg font-semibold text-text">{delay.student_id}</p>
        </div>
        <div>
          <p className="text-sm text-text/60">Data do Atraso</p>
          <p className="text-lg font-semibold text-text">
            {formatDate(new Date(delay.delay_date))}
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Horário Esperado</p>
          <p className="text-lg font-semibold text-text">
            {formatTime(delay.expected_time)}
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Horário de Chegada</p>
          <p className="text-lg font-semibold text-text">
            {formatTime(delay.arrival_time)}
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Minutos de Atraso</p>
          <p className="text-lg font-semibold text-text text-yellow-400">
            {delay.delay_minutes} min
          </p>
        </div>
        <div>
          <p className="text-sm text-text/60">Registrado por</p>
          <p className="text-lg font-semibold text-text">
            {delay.registered_by_id ? `Porteiro ${delay.registered_by_id}` : "—"}
          </p>
        </div>
      </div>

      {/* Reason */}
      {delay.reason && (
        <div>
          <p className="text-sm text-text/60">Motivo</p>
          <p className="text-base text-text/90">{delay.reason}</p>
        </div>
      )}

      {/* Rejection Reason */}
      {delay.rejection_reason && (
        <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-4">
          <p className="text-sm text-text/60">Motivo da Rejeição</p>
          <p className="text-base text-red-400">{delay.rejection_reason}</p>
        </div>
      )}

      {/* Actions */}
      {delay.status === "PENDING" && (onApprove || onReject) && (
        <div className="flex gap-4 pt-4">
          {onApprove && (
            <button
              onClick={() => onApprove(delay.id)}
              className="px-4 py-2 rounded-lg bg-green-500/20 text-green-400 hover:bg-green-500/30 transition font-semibold"
            >
              Aprovar
            </button>
          )}
          {onReject && (
            <button
              onClick={() => onReject(delay.id)}
              className="px-4 py-2 rounded-lg bg-red-500/20 text-red-400 hover:bg-red-500/30 transition font-semibold"
            >
              Rejeitar
            </button>
          )}
        </div>
      )}

      {/* Approved/Rejected By */}
      {delay.status !== "PENDING" && (
        <div className="text-sm text-text/60 pt-4 border-t border-text/20">
          <p>
            {delay.status === "APPROVED"
              ? `Aprovado por: Coordenador ${delay.approved_by_id}`
              : `Rejeitado por: Coordenador ${delay.approved_by_id}`}
          </p>
        </div>
      )}
    </div>
  );
}
