import { useState, useEffect } from "react";
import { Button } from "@/components/ui/Button";
import { TextField } from "@/components/ui/TextField";
import { AutocompleteInput } from "@/components/ui/AutocompleteInput";
import type { OccurrenceCreate } from "@/features/occurrences/services/occurrencesApi";
import type { UserPublic } from "@/features/auth/services/usersApi";
import { useCurrentLesson } from "@/features/schedules/hooks/useSchedules";

type OccurrenceFormProps = {
  onSubmit: (data: OccurrenceCreate) => Promise<void>;
  isLoading?: boolean;
  onCancel?: () => void;
};

export function OccurrenceForm({
  onSubmit,
  isLoading,
  onCancel,
}: OccurrenceFormProps) {
  const [selectedStudent, setSelectedStudent] = useState<UserPublic | null>(null);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [error, setError] = useState("");

  const { data: currentLesson } = useCurrentLesson();

  useEffect(() => {
    // Auto-preencher título com informações da aula atual
    if (currentLesson?.in_class && currentLesson.period) {
      const periodName = currentLesson.period.name;
      const weekday = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"][currentLesson.weekday || 0];
      setTitle(`${periodName} - ${weekday}`);
    }
  }, [currentLesson]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!selectedStudent || !title || !description) {
      setError("Preencha todos os campos obrigatórios");
      return;
    }

    try {
      await onSubmit({
        student_id: selectedStudent.id,
        title,
        description,
      });

      // Reset form on success
      setSelectedStudent(null);
      setTitle("");
      setDescription("");
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Erro ao criar ocorrência"
      );
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 max-w-2xl">
      {error && (
        <div className="rounded-lg bg-red-500/10 border border-red-500/30 p-4 text-red-400">
          {error}
        </div>
      )}

      <div className="flex flex-col gap-4">
        <AutocompleteInput
          label="Aluno"
          placeholder="Digite o nome do aluno..."
          value={selectedStudent}
          onChange={setSelectedStudent}
          required
        />

        <TextField
          label="Título da Ocorrência"
          placeholder="Ex: Comportamento inadequado"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />

        <div className="flex flex-col gap-1">
          <label className="text-sm font-medium text-text-muted">
            Descrição
          </label>
          <textarea
            placeholder="Descreva os detalhes da ocorrência..."
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            className="w-full rounded-2xl border-4 border-primary bg-transparent px-5 py-3 text-text shadow-md placeholder:text-text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/40"
            rows={4}
          />
        </div>

        {currentLesson?.in_class && (
          <div className="rounded-lg bg-green-500/10 border border-green-500/30 p-4 text-green-400">
            <p className="text-sm">
              <strong>Aula atual:</strong> {currentLesson.period?.name} - Turma {currentLesson.classroom_id}
            </p>
          </div>
        )}

        {!currentLesson?.in_class && (
          <div className="rounded-lg bg-yellow-500/10 border border-yellow-500/30 p-4 text-yellow-400">
            <p className="text-sm">
              Você não está em período de aula no momento.
            </p>
          </div>
        )}
      </div>

      <div className="flex gap-4">
        <Button type="submit" variant="primary" disabled={isLoading}>
          {isLoading ? "Criando..." : "Criar Ocorrência"}
        </Button>
        {onCancel && (
          <Button type="button" variant="ghost" onClick={onCancel}>
            Cancelar
          </Button>
        )}
      </div>
    </form>
  );
}
