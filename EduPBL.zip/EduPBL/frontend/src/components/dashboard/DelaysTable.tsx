import { cn } from "@/utils/cn";
import type { DelayPublic } from "@/features/delays/services/delaysApi";
import { formatDate, formatTime } from "../../utils/date";

type DelaysTableProps = {
  delays?: DelayPublic[];
  isLoading?: boolean;
  onSelectDelay?: (id: number) => void;
  onApprove?: (id: number) => void;
  onReject?: (id: number) => void;
  showActions?: boolean;
  className?: string;
};

function getStatusColor(status: string) {
  switch (status) {
    case "APPROVED":
      return "bg-green-500/20 text-green-400";
    case "REJECTED":
      return "bg-red-500/20 text-red-400";
    case "PENDING":
      return "bg-yellow-500/20 text-yellow-400";
    default:
      return "bg-text/10 text-text/60";
  }
}

function getStatusLabel(status: string) {
  switch (status) {
    case "APPROVED":
      return "Aprovado";
    case "REJECTED":
      return "Rejeitado";
    case "PENDING":
      return "Pendente";
    default:
      return status;
  }
}

export function DelaysTable({
  delays,
  isLoading,
  onSelectDelay,
  onApprove,
  onReject,
  showActions = false,
  className,
}: DelaysTableProps) {
  const displayRows = delays || [];
  const hasItems = displayRows.length > 0;
  const columns = showActions
    ? "grid-cols-[1fr_0.9fr_1fr_1fr_0.9fr_1.2fr]"
    : "grid-cols-[1.2fr_0.9fr_1fr_1fr_0.9fr]";

  return (
    <div
      className={cn(
        "overflow-x-auto rounded-[20px] border border-text/40 bg-surface/10 backdrop-blur-sm",
        className
      )}
    >
      {/* Header */}
      <div
        className={cn(
          `grid ${columns} gap-0 border-b border-text/30`,
          "bg-gradient-to-r from-transparent via-text/5 to-transparent px-4 py-3 text-sm font-medium text-text md:text-base"
        )}
      >
        <div className="px-2">Aluno</div>
        <div className="px-2">Data</div>
        <div className="px-2">Horário</div>
        <div className="px-2">Tempo (min)</div>
        <div className="px-2">Status</div>
        {showActions && <div className="px-2">Ações</div>}
      </div>

      {/* Rows */}
      <div className="divide-y divide-text/20">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div
              key={i}
              className={`grid ${columns} px-4 py-4 text-sm md:text-base`}
            >
              {Array.from({ length: showActions ? 6 : 5 }).map((_, j) => (
                <div
                  key={j}
                  className="px-2 h-4 bg-text/10 rounded animate-pulse"
                />
              ))}
            </div>
          ))
        ) : !hasItems ? (
          <div className="col-span-full px-4 py-8 text-center text-text/60">
            Nenhum atraso registrado
          </div>
        ) : (
          displayRows.map((row) => (
            <div
              key={row.id}
              onClick={() => onSelectDelay?.(row.id)}
              className={`grid ${columns} px-4 py-4 text-sm text-text/95 md:text-base hover:bg-surface/10 transition cursor-pointer`}
            >
              <div className="truncate px-2">Aluno {row.student_id}</div>
              <div className="px-2 text-text/70">
                {formatDate(new Date(row.delay_date))}
              </div>
              <div className="px-2 text-text/70">
                {formatTime(row.arrival_time)}
              </div>
              <div className="px-2 font-semibold">{row.delay_minutes}</div>
              <div className="px-2">
                <span
                  className={cn(
                    "inline-block px-3 py-1 rounded-full text-xs font-semibold",
                    getStatusColor(row.status)
                  )}
                >
                  {getStatusLabel(row.status)}
                </span>
              </div>
              {showActions && (
                <div className="px-2 flex gap-2">
                  {row.status === "PENDING" && (
                    <>
                      <button
                        onClick={() => onApprove?.(row.id)}
                        className="px-2 py-1 rounded text-xs bg-green-500/20 text-green-400 hover:bg-green-500/30 transition"
                      >
                        Aprovar
                      </button>
                      <button
                        onClick={() => onReject?.(row.id)}
                        className="px-2 py-1 rounded text-xs bg-red-500/20 text-red-400 hover:bg-red-500/30 transition"
                      >
                        Rejeitar
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
