import { useState, useEffect, useRef } from "react";
import { useSearchUsers } from "@/features/auth/hooks/useUsers";
import type { UserPublic } from "@/features/auth/services/usersApi";

interface AutocompleteInputProps {
  label: string;
  placeholder: string;
  value: UserPublic | null;
  onChange: (user: UserPublic | null) => void;
  required?: boolean;
}

export function AutocompleteInput({
  label,
  placeholder,
  value,
  onChange,
  required,
}: AutocompleteInputProps) {
  const [inputValue, setInputValue] = useState(value ? `${value.first_name} ${value.last_name}` : "");
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLUListElement>(null);

  const { data: searchResults, isLoading } = useSearchUsers(inputValue, "student", 10);

  useEffect(() => {
    if (value) {
      setInputValue(`${value.first_name} ${value.last_name}`);
    } else {
      setInputValue("");
    }
  }, [value]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInputValue(newValue);
    setIsOpen(newValue.length > 0);
    setSelectedIndex(-1);
    if (newValue.length === 0) {
      onChange(null);
    }
  };

  const handleSelect = (user: UserPublic) => {
    setInputValue(`${user.first_name} ${user.last_name}`);
    onChange(user);
    setIsOpen(false);
    setSelectedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || !searchResults?.users) return;

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        setSelectedIndex(prev =>
          prev < searchResults.users.length - 1 ? prev + 1 : prev
        );
        break;
      case "ArrowUp":
        e.preventDefault();
        setSelectedIndex(prev => prev > 0 ? prev - 1 : -1);
        break;
      case "Enter":
        e.preventDefault();
        if (selectedIndex >= 0 && selectedIndex < searchResults.users.length) {
          handleSelect(searchResults.users[selectedIndex]);
        }
        break;
      case "Escape":
        setIsOpen(false);
        setSelectedIndex(-1);
        break;
    }
  };

  const handleBlur = () => {
    // Delay to allow click on list items
    setTimeout(() => setIsOpen(false), 150);
  };

  return (
    <div className="flex flex-col gap-1 relative">
      <label className="text-sm font-medium text-text-muted">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
      </label>
      <input
        ref={inputRef}
        type="text"
        placeholder={placeholder}
        value={inputValue}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        onFocus={() => inputValue.length > 0 && setIsOpen(true)}
        onBlur={handleBlur}
        required={required}
        className="w-full rounded-2xl border-4 border-primary bg-transparent px-5 py-3 text-text shadow-md placeholder:text-text-muted focus:border-accent focus:outline-none focus:ring-2 focus:ring-accent/40"
      />
      {isOpen && searchResults?.users && searchResults.users.length > 0 && (
        <ul
          ref={listRef}
          className="absolute top-full left-0 right-0 bg-surface border border-text/20 rounded-2xl shadow-lg z-10 max-h-48 overflow-y-auto mt-1"
        >
          {searchResults.users.map((user, index) => (
            <li
              key={user.id}
              onClick={() => handleSelect(user)}
              className={`px-4 py-2 cursor-pointer hover:bg-primary/10 ${
                index === selectedIndex ? "bg-primary/20" : ""
              }`}
            >
              {user.first_name} {user.last_name} ({user.username})
            </li>
          ))}
        </ul>
      )}
      {isLoading && inputValue.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-surface border border-text/20 rounded-2xl shadow-lg z-10 p-4 text-center">
          Buscando...
        </div>
      )}
    </div>
  );
}