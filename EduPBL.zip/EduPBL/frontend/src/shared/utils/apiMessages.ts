/**
 * apiMessages.ts — Tradução centralizada de mensagens retornadas pela API.
 *
 * Por que no frontend?
 *   O backend retorna mensagens em inglês (ou mistas) nos campos `detail` e
 *   `message`. Traduzir aqui é mais versátil: não exige tocar no backend a
 *   cada ajuste de texto, e mantém as mensagens de usuário em um único lugar.
 *
 * Como usar:
 *   import { translateApiMessage } from "@/shared/utils/apiMessages";
 *
 *   const msg = translateApiMessage(err?.response?.data?.detail);
 *   // → "Nome de usuário já está em uso"
 *
 * Como adicionar uma nova tradução:
 *   Basta inserir uma nova entrada em API_MESSAGES abaixo.
 *   A chave deve ser a string exata retornada pelo backend (campo `detail`
 *   ou `message`). O valor é o texto que será exibido ao usuário.
 */

const API_MESSAGES: Record<string, string> = {
  // ── Autenticação ──────────────────────────────────────────────────────────
  "Incorrect email or password": "E-mail ou senha incorretos.",
  "Could not validate credentials": "Sessão inválida. Faça login novamente.",
  "Logout successful": "Logout realizado com sucesso.",

  // ── Usuários ──────────────────────────────────────────────────────────────
  "User not found": "Usuário não encontrado.",
  "Student not found": "Aluno não encontrado.",
  "Teacher not found": "Professor não encontrado.",
  "Username already exists": "Nome de usuário já está em uso.",
  "Email already exists": "E-mail já está em uso.",
  "Username or Email already exists":
    "Nome de usuário ou e-mail já está em uso.",
  "Current password is incorrect": "Senha atual incorreta.",
  "Password updated successfully": "Senha atualizada com sucesso.",
  "Not enough permissions": "Você não tem permissão para realizar esta ação.",
  "Insufficient permissions": "Você não tem permissão para realizar esta ação.",
  "User deactivated successfully": "Usuário desativado com sucesso.",
  "User deleted": "Usuário excluído com sucesso.",
  "User is not a student": "Este usuário não é um aluno.",

  // ── Avatar ────────────────────────────────────────────────────────────────
  "Avatar not found": "Avatar não encontrado.",

  // ── Atrasos ───────────────────────────────────────────────────────────────
  "Delay not found": "Atraso não encontrado.",
  "Delay already decided": "Este atraso já foi analisado.",
  "Delay has not been decided yet": "Este atraso ainda não foi analisado.",
  "Delay already registered for this student today":
    "Já existe um atraso registrado para este aluno hoje.",

  // ── Ocorrências ───────────────────────────────────────────────────────────
  "Occurrence not found": "Ocorrência não encontrada.",

  // ── Horários / turmas ─────────────────────────────────────────────────────
  "classroom_ids must be provided when affects_all=False":
    "Informe ao menos uma turma quando a opção 'afeta todas' estiver desativada.",
};

/**
 * Traduz uma mensagem retornada pela API para português.
 *
 * - Se a mensagem tiver uma tradução cadastrada, retorna o texto traduzido.
 * - Caso contrário, retorna a mensagem original (para não suprimir erros
 *   inesperados nem já em português vindos do backend).
 * - Se `message` for nulo/undefined, retorna o `fallback` informado.
 *
 * @param message  Valor do campo `detail` ou `message` da resposta da API.
 * @param fallback Texto exibido quando a mensagem estiver ausente.
 */
export function translateApiMessage(
  message: string | null | undefined,
  fallback = "Ocorreu um erro inesperado. Tente novamente.",
): string {
  if (!message) return fallback;
  return API_MESSAGES[message] ?? message;
}

/**
 * Extrai e traduz a mensagem de erro de uma exceção Axios.
 *
 * Cobre tanto `detail` (FastAPI/HTTPException) quanto `message`
 * (respostas de sucesso com body JSON).
 *
 * Uso típico no catch de uma chamada à API:
 *   setError(extractApiError(err));
 */
export function extractApiError(
  err: unknown,
  fallback = "Ocorreu um erro inesperado. Tente novamente.",
): string {
  const data = (
    err as { response?: { data?: { detail?: string; message?: string } } }
  )?.response?.data;
  const raw = data?.detail ?? data?.message ?? null;
  return translateApiMessage(raw, fallback);
}
