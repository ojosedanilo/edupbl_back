# EduPBL — Frontend

## 🖥️ Tecnologias

- **Node.js** → runtime JS
- **pnpm** → gerenciador de pacotes
- **Vite** → bundler/dev server
- **React + TypeScript** → UI
- **SWC** → compilador
- **TanStack Query** → estado servidor
- **React Router** → rotas
- **TailwindCSS** → estilos utilitários
- **Material UI (MUI)** → biblioteca de componentes UI

## 📁 Estrutura

```
frontend/
├── src/
│   ├── components/   → componentes reutilizáveis (layout, ui)
│   ├── features/     → funcionalidades com domínio próprio (auth…)
│   ├── pages/        → páginas da aplicação
│   ├── shared/       → serviços e utilitários compartilhados
│   └── styles/       → estilos globais
├── package.json
├── vite.config.ts
└── tsconfig.app.json
```

## 📋 Pré-requisitos

- [Node.js](https://nodejs.org/) (versão LTS recomendada)
- [pnpm](https://pnpm.io/installation)

## 🚀 Setup

### 1. Copiar e configurar variáveis de ambiente

```bash
cp .env.example .env
# Edite o .env com a URL da API, se necessário
```

### 2. Instalar dependências

```bash
pnpm install
```

### 3. Iniciar o servidor de desenvolvimento

```bash
pnpm run dev
```
